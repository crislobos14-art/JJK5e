# Jujutsu Kaisen 5e (V.6) — Foundry VTT module

Unofficial, non-commercial conversion of *Jujutsu Kaisen 5e* V.6 (by I watch Anime) for the **D&D 5e** system.
Content is in English, as in the original document.

## Requirements

- Foundry VTT v12 or v13
- dnd5e system 4.x (Foundry v12) or 5.x (Foundry v13)

## Installation

1. Unzip the archive into your Foundry `Data/modules/` folder, so you get `Data/modules/jjk5e/module.json`.
2. Restart Foundry (or return to Setup), open your world and enable **Jujutsu Kaisen 5e (V.6) — Compendium**
   under *Game Settings → Manage Modules*.
3. As GM, accept the import prompt. The module creates world compendiums inside the **JJK 5e V.6** compendium folder.
   To rebuild them later: *Game Settings → Configure Settings → Jujutsu Kaisen 5e → Import / Update compendiums*.

## What you get

| Compendium | Content |
|---|---|
| JJK 5e: Classes | Juggernaut, Scout, Strategist, Shikigami User, Support Specialist, Warrior, Heavenly Restriction + Ideals (Prideful, Vengeful) |
| JJK 5e: Class Features | All class features (granted automatically on level-up), Cursed Energy pools, Body Improvements |
| JJK 5e: Innate Techniques | 81 techniques (incl. ████ and Light and Vairocana from Creeps and Curses, with their feats and Reversals), one folder each, features tagged with their level (1/3/6/11/18) |
| JJK 5e: Races | 11 race/subrace options with their traits |
| JJK 5e: Feats → Creeps and Curses | From *Creeps and Curses V.3.1*: 5 Heavenly Pacts, Evolutionary Constraint (+ True Rebirth), 9 Special Grade Boons, 4 Special Traits × 3 tiers (Six Eyes, Perfect Form, Cursed Lover, Living Prison), 8 example Minor/Major Cursed Techniques |
| JJK 5e: Feats | Barrier, Cursed Energy, Physical, RCT, Skill and Innate Technique feats (with prerequisites) |
| JJK 5e: Backgrounds & Mindsets | 5 backgrounds, mindsets |
| JJK 5e: Equipment & Cursed Tools | Armor, melee/ranged weapons (dollar prices converted: $100 = 1 gp), packs, cursed tools by grade |
| JJK 5e: Macros | Choose Innate Technique, Set CE Ability, Spend / Regain CE, Negative Emotion Recovery, Short Rest CE Recovery, Import / Update |
| JJK 5e: Roll Tables | Limb Damage, Consequences of Breaking a Binding Vow, Deadly Sentencing evidence |
| JJK 5e: Rules | The whole book as journals (Binding Vows, Domain Expansion, Black Flash, Limb Damage, The Zone, etc.) |

## How to build a character

1. Drag a **race** and a **class** onto the sheet. Class level-up grants HP, saves, proficiencies, skills,
   ASIs and the class features automatically.
2. At level 1 you also get **Cursed Energy (Class)**: a feature with limited uses = your CE pool.
   Maximum = class table value + the higher of WIS/CHA modifier (Support Specialist also adds proficiency).
   If your CE score is the lower one, edit the uses formula.
3. Select the token and run the macro **JJK: Choose Innate Technique** (compendium *JJK 5e: Macros*).
   It adds the technique features for your highest class level, and adds the new ones automatically
   every time you level up (1, 3, 6, 11, 18). You can still drag features by hand.
4. Heavenly Restriction: no Cursed Energy pool; STR/DEX/CON bonuses (+2 at 1st, +1 at 5/9/13/17) and the
   unarmored AC are applied automatically; choose the Ideal (subclass) at level 3.

## Cursed Energy automation

Technique and class features that state a fixed cost ("as an action for 3 cursed energy") have one activity per
cost (e.g. *Action (3 CE)*, *Reaction (2 CE)*). When used, the cost is deducted from the actor's Cursed Energy pool
and the use is blocked if there is not enough CE. Variable or extra costs ("up to your CE modifier",
"an additional 5 CE") must still be spent by hand: click the uses on the Cursed Energy feature, or run in a macro:

```js
const api = game.modules.get("jjk5e").api;
await api.spendCE(token.actor, 4, "Reinforcement");   // spend 4
await api.regainCE(token.actor, 2);                    // regain 2 (e.g. short rest hit dice)
```

Both behaviours can be switched off in the module settings.

## JJK panel and token bar

- Every character sheet gets a **JJK** button in its header (or run the macro *JJK: Open Panel*). The panel shows:
  Cursed Energy bar (−1 / +1 / spend / regain / Negative Emotion / short rest), technique and CE ability,
  Domain / Burnout / The Zone / pending Black Flash, Maximum & Reduced Output, Soul Awareness, Limb Damage and Summons.
- The CE pool is mirrored into an actor resource (tertiary by default, see settings) and used as the token's second bar
  when that bar is free. Editing the bar on the token updates the pool and vice versa.

## Automated rules

**Techniques, feats and features**
- Activities built from the text: saving throws (DC = 8 + PB + CE modifier), Cursed Energy attacks, damage,
  healing / temporary HP, area templates, range and duration.
- Damage that grows with level ("increases to 1d8 at 3rd level…") is updated automatically on level-up.
- Fixed CE costs are spent automatically; "for every CE" costs use the scaling field of the use dialog
  (base cost + 1 CE per step), e.g. *Cursed Strike*, *Kirin*, *Reverse Cursed Technique*.
- **CE ability**: the macro *Set Cursed Energy Ability* (asked automatically by *Choose Innate Technique*) fixes the
  CE pool to WIS or CHA and sets the sheet's spellcasting ability, used for CE save DCs and attacks.

**Breakthroughs and domains**
- **Black Flash**: on a melee critical hit the module rolls the d20; on success it posts the result and applies or
  stacks **The Zone** (+1 crit range per stack, Black Flash range included) and removes Technique Burnout.
- **Domain Expansion**: *Expand Domain (20 CE)* activity with the 175-ft template. Using it adds a 1-minute effect;
  delete that effect when the domain closes and **Technique Burnout** is applied (2 exhaustion, technique
  features blocked until you delete it or land a Black Flash).
- *Reverse Cursed Technique (Healing Pool)* and *Cursed Strike* / *Cursesight* (offered as optional at level 1).

**Feats (Innate Technique, Cursed Energy and the rest)**
- **Prerequisites** are checked when a feat is added: missing features, CE score, level or skill trigger a warning.
- **Modifier reminders**: using a technique feature posts in the chat the feats you own that modify it
  (e.g. *Double Up* when you use *Kaichi*).
- **Extra CE costs** ("for an additional 3 CE…") are their own *Extra (N CE)* activities: one click pays them.
- **Conditions** that techniques and feats impose (frightened, stunned, restrained, poisoned, prone…) are effects you
  can apply to the targets from the chat card.
- **Rider damage / temporary HP** ("additional fire damage equal to your proficiency bonus") get their own roll.
- **Passive bonuses** (resistances, speed, AC, senses, skills, HP, ability scores) are effects; conditional ones are
  disabled *toggle* effects you switch on when they apply.
- Cursed Energy feats: *Cursed Energy Trait / Mastery* (enable the chosen option; Rough / Elemental bonuses are added
  to Cursed Strike and Cursed Energy Slash automatically, Smooth gives AC/speed/damage reduction, Elemental riders apply
  their conditions), *Curse Enhanced Body* (AC + CE mod, halved with Unarmored Defense), *Immense* (+1 CE score and
  + CE mod to the pool), *Bottomless* (+2 CE per level), *Malevolent* (WIS save, 100-ft area, frightened + penalty),
  *Blessed by Black Sparks* (+3 Black Flash range), *Cursed Enhancement / Imbuement* (scaled CE costs).

**Character building**
- Feats with an ability increase or proficiencies (Athlete, Resilient, Skilled, Weapon Expert, Lightly Armored…) ask for
  the choice when added (dnd5e advancement).
- Backgrounds offer their feat category (e.g. *Clan Sorcerer → Innate Technique feat*) and their tool proficiency.
- Heavenly Restriction: Fighting Style (level 2) and Improved Fighting Style (level 14) are chosen from items with their
  effects (Archery +2 ranged attack, Blind Fighting blindsight, Dueling toggle…). Body Improvements check body points
  (= HR level, + Peak Form), the per-category limit (ability modifier) and their prerequisites. *Fighting Initiate* and
  *Peak Form* offer the matching choice.
- Mindsets: *Use Inspiration* activity (spends the sheet's inspiration; blocked if you have none).
- Races: Sumerian (Deskunte, Rumelian, Shaama) from Creeps and Curses; Cursed Spirit immunity to nonmagical B/P/S.

**Class features**
- *Innate Technique* opens the technique chooser. *Focus* and *Vengeful Fury* switch on all their linked effects
  (resistances, damage reduction, extra critical dice from Immense Anger / Follow Your Wrath, necrotic resistance from
  Curse Resistance) for 1 minute (Endless Focus: until ended). *Reckless Blows* gives advantage on melee attacks for the turn.
- *Brutal Blows* / *Weapon Specialist* add critical dice by level; *Steel Spirit* gives all saving throws;
  *Unstoppable* (Warrior) has 1–2 rerolls; *Quick Recovery* is a CE recovery pool; *Sorcerous Restoration* adds 4 CE on
  each short rest; *Lock In*, *Sharp Eyes*, *Unerring Blows* have their rolls / uses.

**Equipment**
- The full Creeps and Curses cursed tool compendium (76 tools by grade): weapons with their base stats and +bonus,
  potions that heal and are consumed, wearable items as equipment, activities and CE costs from their text.

**Combat extras**
- **Black Flash ×3**: after a successful Black Flash the next critical damage roll uses 3× dice automatically.
- **The Zone** gives advantage on attack rolls (setting) on top of the crit / Black Flash range.
- **Domain sure-hit**: while your domain is open, technique attacks and saves post a sure-hit reminder.
- **Maximum Output** (panel / macro): spends half the base cost + 2 per Reduced Output level; a second use in the same
  combat round rolls the CE check (DC 15 + 2 per level) and adds Reduced Output on a failure.
- **Reduced Output**: techniques whose base CE cost exceeds the level's Max are blocked; Black Flash removes one level.
- **Soul Awareness**: level tracker with an effect listing the unlocked abilities.
- **Limb Damage**: thresholds (CON mod × level, ×2 for torso / head) and Broken / Lost effects (half speed for legs,
  half max HP for a broken torso, unconscious / dead for the head); *Roll limb* draws the Limb Damage table.
- **Summons**: type a name (e.g. *Ink Wolf*, *Wolf*, or any actor in a world folder named "JJK Shikigami") and the
  token appears next to yours; the GM must be online. The creature is taken from your actors or from the SRD
  compendium (imported into the "JJK Summons" folder). Shikigami stat blocks are not part of the book, create them as
  actors in "JJK Shikigami".
- Domain, Technique Burnout and The Zone end on their own when their duration runs out (or via Times Up if active).

**Classes and races**
- Unarmed Strike per class using the class damage die (Juggernaut, Scout, Shikigami User, Warrior, HR).
- Scout speed bonus and HR Unarmored Movement follow the class table automatically.

- Race ability score increases, skill/weapon proficiencies, poison resistance/immunities.
- Unarmored Defense (10 + DEX + CON), Hard Shell (14 + CON), Integrated Armor (+1 AC), Defensive weapons (+1 AC).
- Durable Body / Strong Constitution HP per level, Powerful Build, Honed Instincts (advantage on initiative).
- Juggernaut *Focus*: a disabled effect on the feature; enable it while focused for B/P/S resistance.
- Juggernaut *Unstoppable* (+4 STR/CON at 20).

## Creeps and Curses notes

- Special Traits: add every tier you reach (Dormant 1, Stirring 6, Awakened 14); HP, ability, speed, senses and
  resistance bonuses are automated per tier.
- *Unkillable* (+50 HP) and *Unending Cursed Energy Reserves* (+20 CE max, added to your CE pool) are automated.
- Reversals are in the technique folders but are never added automatically (they need Reverse Cursed Technique).
- The Vairocana Chaos Table is not part of V.3.1. Curse stat blocks (Chapter 2) are not included.

## Known limits

- Sure-hit is a reminder: the targets' failed saves / hits still have to be applied from the chat card.
- Conditions applied by techniques (restrained, blinded…) are not automated.
- Black Flash ignoring resistances and arm-limb disadvantage are reminders, not mechanics.
- Effects with a duration are not removed by themselves (Foundry needs a module like Times Up for that).
- The automatic text parsing may set a wrong action type or miss a CE cost on a few features: check the
  activities if something looks off, and edit them freely (the compendium is unlocked with the lock icon).
- Handguns are martial weapons: for Shikigami User, Support Specialist and Strategist tick "Proficient" on the
  weapon by hand (their handgun proficiency has no dnd5e equivalent).
- Human ASI is 7 points with a cap of 2: pick +2 for one ability and +1 for each of the others.
- Prices in gp follow the book's conversion table ($1 = 1 cp, $10 = 1 sp, $100 = 1 gp).

## Languages

Interface (panel, notifications, settings, dialogs) in English and Spanish, following Foundry's language setting.
Game content (items, journal) stays in English, as in the original book.

## License

CC BY-NC-SA 4.0 — see `LICENSE.txt`. Non-commercial use only.
