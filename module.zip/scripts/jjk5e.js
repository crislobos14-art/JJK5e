/**
 * Jujutsu Kaisen 5e (V.6) — Foundry VTT module for the dnd5e system (4.x / 5.x).
 *
 * - Importer: builds world compendiums from the bundled JSON data.
 * - Cursed Energy: pool items, automatic spending, token bar sync, CE ability (WIS/CHA).
 * - Innate Techniques: choose + auto-grant on level-up, damage / speed scaling.
 * - Black Flash (check, ×3 critical dice), The Zone (crit range, advantage), Domain Expansion (sure-hit notes,
 *   Technique Burnout), Maximum / Reduced Output, Soul Awareness, Limb Damage, summons.
 * - JJK panel on character sheets, Spanish / English UI, effect expiry (unless Times Up is active).
 */
const MODULE_ID = "jjk5e";
const DATA_VERSION = "1.10.0";
const FOLDER_NAME = "JJK 5e V.6";
const ICONS = `modules/${MODULE_ID}/icons`;

const log = (...args) => console.log(`${MODULE_ID} |`, ...args);

/* -------------------------------------------- */
/*  Helpers                                      */
/* -------------------------------------------- */

/** Localize "JJK5E.<key>" with optional data; falls back to the key. */
function t(key, data) {
  const k = `JJK5E.${key}`;
  if (!game.i18n?.has?.(k)) return data ? `${key} ${JSON.stringify(data)}` : key;
  return data ? game.i18n.format(k, data) : game.i18n.localize(k);
}

const docClass = (type) => CONFIG[type]?.documentClass ?? globalThis[type];
const setting = (key) => game.settings.get(MODULE_ID, key);
const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function getCompendiumClass() {
  return foundry.documents?.collections?.CompendiumCollection ?? globalThis.CompendiumCollection;
}

async function confirmDialog(title, content) {
  return foundry.applications.api.DialogV2.confirm({ window: { title }, content, rejectClose: false });
}

/** Prompt with a form; returns the named field value (or null). */
async function promptField(title, content, field, asNumber = false) {
  const read = (root) => {
    const el = root?.querySelector?.(`[name="${field}"]`) ?? root?.elements?.[field];
    if (!el) return null;
    return asNumber ? el.valueAsNumber : el.value;
  };
  return foundry.applications.api.DialogV2.prompt({
    window: { title }, content, rejectClose: false,
    ok: { label: t("Common.OK"), callback: (event, button, dialog) => read(button.form ?? dialog?.element ?? dialog) }
  });
}

async function promptNumber(title, label, value = 1) {
  const content = `<p>${label}</p><input type="number" name="amount" value="${value}" min="0" step="1" style="width:100%">`;
  return Number(await promptField(title, content, "amount", true)) || 0;
}

async function fetchJSON(path) {
  const response = await fetch(`modules/${MODULE_ID}/${path}`);
  if (!response.ok) throw new Error(`Could not load ${path} (${response.status})`);
  return response.json();
}

function folderDepth(folder, byId) {
  let depth = 0;
  let current = folder;
  while (current?.folder) {
    depth += 1;
    current = byId.get(current.folder);
  }
  return depth;
}

function pickActor(actor) {
  return actor ?? canvas?.tokens?.controlled?.[0]?.actor ?? game.user.character ?? null;
}

function requireActor(actor) {
  actor = pickActor(actor);
  if (!actor) ui.notifications.warn(t("Notify.NoActor"));
  return actor;
}

async function chat(actor, content, extra = {}) {
  const Chat = docClass("ChatMessage");
  return Chat.create({ speaker: Chat.getSpeaker({ actor }), content, ...extra });
}

/* -------------------------------------------- */
/*  Importer                                     */
/* -------------------------------------------- */

async function importAll() {
  if (!game.user.isGM) return;
  const CompendiumCollection = getCompendiumClass();
  const manifest = await fetchJSON("data/manifest.json");

  let compendiumFolder = game.folders.find((f) => f.type === "Compendium" && f.name === FOLDER_NAME);
  if (!compendiumFolder) {
    try {
      compendiumFolder = await docClass("Folder").create({ name: FOLDER_NAME, type: "Compendium", color: "#4b1d6e" });
    } catch (err) {
      log("Compendium folders not supported, skipping.", err);
    }
  }

  ui.notifications.info(t("Import.Start", { n: manifest.length }));
  for (const entry of manifest) {
    const data = await fetchJSON(entry.file);
    const collectionId = `world.${entry.name}`;
    let pack = game.packs.get(collectionId);
    if (!pack) {
      pack = await CompendiumCollection.createCompendium({
        label: entry.label, name: entry.name, type: entry.type, package: "world"
      });
    }
    if (pack.locked) await pack.configure({ locked: false });

    const DocumentClass = docClass(entry.type);
    const FolderClass = docClass("Folder");

    const index = await pack.getIndex();
    const oldIds = index.map((i) => i._id);
    if (oldIds.length) await DocumentClass.deleteDocuments(oldIds, { pack: collectionId });
    const oldFolders = [...(pack.folders?.values?.() ?? [])].map((f) => f.id ?? f._id);
    if (oldFolders.length) await FolderClass.deleteDocuments(oldFolders, { pack: collectionId });

    const byId = new Map(data.folders.map((f) => [f._id, f]));
    const sorted = [...data.folders].sort((a, b) => folderDepth(a, byId) - folderDepth(b, byId));
    const depths = [...new Set(sorted.map((f) => folderDepth(f, byId)))];
    for (const depth of depths) {
      const level = sorted.filter((f) => folderDepth(f, byId) === depth).map((f) => ({ ...f, type: entry.type }));
      await FolderClass.createDocuments(level, { pack: collectionId, keepId: true });
    }

    const docs = entry.type === "Item" ? data.documents.map(fxItem) : data.documents;
    for (let i = 0; i < docs.length; i += 100) {
      await DocumentClass.createDocuments(docs.slice(i, i + 100), { pack: collectionId, keepId: true });
    }

    if (compendiumFolder && typeof pack.setFolder === "function") {
      try { await pack.setFolder(compendiumFolder); } catch (err) { log("setFolder failed", err); }
    }
    await pack.configure({ locked: true });
    log(`Imported ${docs.length} documents into ${collectionId}`);
  }

  try { await importWorldCopies(); } catch (err) { console.error(`${MODULE_ID} | world copies`, err); }
  await game.settings.set(MODULE_ID, "importedVersion", DATA_VERSION);
  ui.notifications.info(t("Import.Done"));
}

/** Roll tables and macros also go to the world sidebar, so they can be rolled and dragged to the hotbar directly. */
async function importWorldCopies() {
  for (const [type, file] of [["RollTable", "data/jjk5e-tables.json"], ["Macro", "data/jjk5e-macros.json"],
    ["Actor", "data/jjk5e-shikigami.json"]]) {
    const data = await fetchJSON(file);
    const Cls = docClass(type);
    const coll = type === "Macro" ? game.macros : type === "Actor" ? game.actors : game.tables;
    const keepId = type === "Actor";
    const old = coll.filter((d) => d.flags?.jjk5e?.worldCopy).map((d) => d.id);
    if (old.length) await Cls.deleteDocuments(old);
    let folder = game.folders.find((f) => f.type === type && f.name === FOLDER_NAME);
    if (!folder) folder = await docClass("Folder").create({ name: FOLDER_NAME, type, color: "#4b1d6e" });
    const docs = data.documents.map((d) => {
      const o = foundry.utils.deepClone(d);
      if (!keepId) delete o._id;
      o.folder = folder?.id ?? null;
      o.ownership = { default: keepId ? 3 : 2 };
      foundry.utils.setProperty(o, "flags.jjk5e.worldCopy", true);
      if (Array.isArray(o.results)) o.results = o.results.map(({ _id, ...r }) => r);
      return o;
    });
    await Cls.createDocuments(docs, { keepId });
  }
}

async function promptImport(reimport = false) {
  const ok = await confirmDialog("JJK 5e V.6", reimport ? t("Import.ConfirmUpdate") : t("Import.ConfirmNew"));
  if (ok) await importAll();
}

const AppV2 = foundry.applications?.api?.ApplicationV2;
class JJKImportMenu extends (AppV2 ?? FormApplication) {
  async render() {
    promptImport(true);
    return this;
  }
}

/* -------------------------------------------- */
/*  Cursed Energy pool                           */
/* -------------------------------------------- */

function findPool(actor) {
  if (!actor) return null;
  const pools = actor.items.filter((i) => i.flags?.jjk5e?.cePool);
  if (!pools.length) return null;
  return pools.sort((a, b) => (Number(b.system.uses?.max) || 0) - (Number(a.system.uses?.max) || 0))[0];
}

function poolValue(pool) {
  const uses = pool.system.uses ?? {};
  if (Number.isFinite(uses.value)) return uses.value;
  return (Number(uses.max) || 0) - (Number(uses.spent) || 0);
}

function poolMax(pool) {
  return Number(pool?.system.uses?.max) || 0;
}

function ceAbility(actor) {
  const a = actor.system.abilities ?? {};
  return actor.getFlag(MODULE_ID, "ceAbility") ?? ((a.cha?.mod ?? 0) > (a.wis?.mod ?? 0) ? "cha" : "wis");
}

function ceMod(actor) {
  return Number(actor.system.abilities?.[ceAbility(actor)]?.mod) || 0;
}

function activityCost(activity) {
  const costs = activity?.item?.flags?.jjk5e?.ceCosts;
  return Number(costs?.[activity.id] ?? 0);
}

async function spendCE(actor, amount, label = "") {
  const pool = findPool(actor);
  if (!pool) {
    ui.notifications.warn(t("Notify.NoPool", { name: actor?.name ?? "?" }));
    return false;
  }
  const value = poolValue(pool);
  const spent = Number(pool.system.uses?.spent) || 0;
  const max = poolMax(pool);
  const newSpent = clamp(spent + amount, 0, max);
  await pool.update({ "system.uses.spent": newSpent });
  const remaining = max - newSpent;
  if (setting("ceChat")) {
    const verb = amount >= 0 ? `−${amount}` : `+${-amount}`;
    await chat(actor, `<p><strong>${esc(label || t("CE.Name"))}</strong>: ${verb} CE `
      + `<span style="opacity:.8">(${t("CE.Remaining", { value: remaining, max })}${value < amount ? `, ${t("CE.Overspent")}` : ""})</span></p>`);
  }
  return true;
}

/* ---- token bar / actor resource sync ---- */

function resourceSlot() {
  const s = setting("ceResource");
  return s && s !== "none" ? s : null;
}

async function syncResource(actor) {
  const slot = resourceSlot();
  if (!slot || !actor?.isOwner) return;
  const pool = findPool(actor);
  if (!pool) return;
  const value = poolValue(pool);
  const max = poolMax(pool);
  const cur = actor.system.resources?.[slot] ?? {};
  const label = t("CE.Name");
  if (cur.value !== value || cur.max !== max || cur.label !== label) {
    await actor.update({
      [`system.resources.${slot}`]: { value, max, label, sr: false, lr: false }
    }, { jjk5eSync: true });
  }
  if (setting("autoTokenBar")) {
    const attr = `resources.${slot}`;
    try {
      if (!actor.isToken && !actor.prototypeToken?.bar2?.attribute) {
        await actor.update({ "prototypeToken.bar2.attribute": attr }, { jjk5eSync: true });
      }
      for (const tok of actor.getActiveTokens(false, true)) {
        if (!tok.bar2?.attribute && tok.isOwner) await tok.update({ "bar2.attribute": attr });
      }
    } catch (err) { log("token bar", err); }
  }
}

async function onActorUpdate(actor, changes, options, userId) {
  if (userId !== game.user.id || options?.jjk5eSync) return;
  const slot = resourceSlot();
  if (!slot) return;
  const v = foundry.utils.getProperty(changes, `system.resources.${slot}.value`);
  if (v === undefined) return;
  const pool = findPool(actor);
  if (!pool) return;
  const max = poolMax(pool);
  await pool.update({ "system.uses.spent": clamp(max - Number(v), 0, max) }, { jjk5eSync: true });
}

/* -------------------------------------------- */
/*  Active effect data: Foundry v14 moved changes to system.changes with a "type" */
/* -------------------------------------------- */

const MODE_TYPES = { 0: "custom", 1: "multiply", 2: "add", 3: "downgrade", 4: "upgrade", 5: "override" };
const fxV14 = () => (Number(game.release?.generation) || 0) >= 14;
const effChanges = (e) => e?.system?.changes ?? e?.changes ?? [];

function toTypedChanges(changes) {
  return (changes ?? []).map((c) => {
    const out = { key: c.key, type: c.type ?? MODE_TYPES[c.mode] ?? "add", value: String(c.value ?? "") };
    if (c._id) out._id = c._id;
    return out;
  });
}

/** Effect creation data in the shape the running core expects. */
function fxData(data) {
  if (!fxV14() || !data) return data;
  let out = data;
  if (Array.isArray(data.changes)) {
    const { changes, ...rest } = data;
    out = { ...rest, system: { ...(rest.system ?? {}), changes: toTypedChanges(changes) } };
  }
  const d = out.duration;
  if (d && (d.rounds || d.seconds || d.turns) && d.value === undefined) {
    const { rounds, seconds, turns, ...restD } = d;
    out = { ...out, duration: rounds ? { ...restD, value: rounds, units: "rounds" }
      : turns ? { ...restD, value: turns, units: "turns" } : { ...restD, value: seconds, units: "seconds" } };
  }
  return out;
}

/** Update data that replaces an effect's changes. */
function fxChanges(changes) {
  return fxV14() ? { "system.changes": toTypedChanges(changes) } : { changes };
}

/** Convert every embedded effect of an item (compendium import). */
function fxItem(doc) {
  if (!fxV14() || !Array.isArray(doc?.effects)) return doc;
  return { ...doc, effects: doc.effects.map((e) => fxData(e)) };
}

/* -------------------------------------------- */
/*  Effects helpers                              */
/* -------------------------------------------- */

function kindEffect(actor, kind) {
  return actor.effects.find((e) => e.flags?.jjk5e?.kind === kind);
}

/** Create / update / delete (data = null) the module effect of the given kind. */
async function setKindEffect(actor, kind, data) {
  const existing = kindEffect(actor, kind);
  if (!data) {
    if (existing) await existing.delete();
    return null;
  }
  data = fxData(foundry.utils.mergeObject(data, { flags: { jjk5e: { kind } } }, { inplace: false }));
  if (existing) return existing.update(data);
  const created = await actor.createEmbeddedDocuments("ActiveEffect", [data]);
  return created?.[0] ?? null;
}

const hasKind = (actor, kind) => !!actor?.effects?.some((e) => e.flags?.jjk5e?.kind === kind && !e.disabled);
const domainOpen = (actor) => !!actor?.effects?.some((e) => (e.flags?.jjk5e?.kind === "domain" || e.flags?.jjk5e?.domainOpen) && !e.disabled);
const inBurnout = (actor) => !!actor?.effects?.some((e) => (e.flags?.jjk5e?.kind === "burnout" || e.flags?.jjk5e?.burnout) && !e.disabled);
const zoneEffect = (actor) => actor?.effects?.find((e) => e.flags?.jjk5e?.kind === "zone" || e.flags?.jjk5e?.zone);

/* -------------------------------------------- */
/*  Activity hooks (CE, burnout, sure-hit)       */
/* -------------------------------------------- */

const RO_MAX = [null, null, null, 8, 8, 8, 6, 6, 6, 3];
const RO_ROWS = [
  "", "-1 Output", "-2 Output, Die Tier (-1)", "-3 Output, 8 Max", "-4 Output, Die Tier (-2)",
  "-5 Output, AP (75%)", "-6 Output, 6 Max, Die Tier (-3)", "-7 Output, DR (50%)", "-8 Output, AP (50%)",
  "-9 Output, 3 Max, Die Tier (-4)"
];

function registerActivityHooks() {
  Hooks.on("dnd5e.preUseActivity", (activity) => {
    const actor = activity.actor ?? activity.item?.actor;
    if (activity.item?.flags?.jjk5e?.mindset && actor && !actor.system.attributes?.inspiration) {
      ui.notifications.warn(t("Notify.NoInspiration", { name: actor.name }));
      return false;
    }
    if (activity.item?.flags?.jjk5e?.technique && inBurnout(actor)) {
      ui.notifications.warn(t("Notify.Burnout"));
      return false;
    }
    const cost = activityCost(activity);
    const ro = Number(actor?.getFlag(MODULE_ID, "reducedOutput")) || 0;
    if (cost && RO_MAX[ro] && cost > RO_MAX[ro]) {
      ui.notifications.warn(t("Notify.ROMax", { cost, max: RO_MAX[ro], level: ro }));
      return false;
    }
    if (!setting("autoSpendCE") || !cost) return;
    const pool = findPool(actor);
    if (!pool) {
      ui.notifications.warn(t("Notify.NoPoolNotSpent", { name: actor?.name ?? "?" }));
      return;
    }
    if (poolValue(pool) < cost) {
      ui.notifications.warn(t("Notify.NotEnoughCE", { value: poolValue(pool), cost }));
      return false;
    }
  });

  Hooks.on("dnd5e.postUseActivity", async (activity, usageConfig) => {
    const actor = activity.actor ?? activity.item?.actor;
    const item = activity.item;
    await remindModifiers(actor, item);
    if (item?.flags?.jjk5e?.openTechnique) await chooseTechnique(actor);
    const grp = item?.flags?.jjk5e?.activatesGroup?.[activity.id];
    if (grp && actor) await activateGroup(actor, grp);
    if (item?.flags?.jjk5e?.mindset && actor?.system.attributes?.inspiration) {
      await actor.update({ "system.attributes.inspiration": false });
      await chat(actor, `<p><strong>${esc(item.name)}</strong> — ${t("Feats.InspirationUsed")}</p>`);
    }
    if (item?.flags?.jjk5e?.domainActivity === activity.id) await openDomain(actor, item);
    else if (item?.flags?.jjk5e?.technique && domainOpen(actor) && setting("domainSureHit")
      && ["attack", "save"].includes(activity.type)) {
      await chat(actor, `<p><strong>${t("Domain.SureHit")}</strong> — ${activity.type === "attack"
        ? t("Domain.SureHitAttack") : t("Domain.SureHitSave")}</p>`);
    }
    if (!setting("autoSpendCE")) return;
    let cost = activityCost(activity);
    if (!cost) return;
    const step = Number(item?.flags?.jjk5e?.ceSteps?.[activity.id] ?? 0);
    const extra = Number(usageConfig?.scaling) || 0;
    if (step && extra > 0) cost += step * extra;
    if (!findPool(actor)) return;
    await spendCE(actor, cost, `${item.name}${activity.name ? ` — ${activity.name}` : ""}`);
  });
}

/* -------------------------------------------- */
/*  Feat links: reminders & prerequisites        */
/* -------------------------------------------- */

const normName = (n) => String(n ?? "").toLowerCase().replace(/[’']/g, "").replace(/\s*:\s*/g, ":").replace(/[^a-z0-9#:]+/g, " ").trim();
const plainText = (htmlStr) => String(htmlStr ?? "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();

function modifiersFor(actor, item) {
  const target = normName(item.name);
  return actor.items.filter((i) => i.id !== item.id && ((i.flags?.jjk5e?.prereq?.features ?? [])
    .some((group) => group.some((n) => normName(n) === target))
    || (i.flags?.jjk5e?.modifies ?? []).some((n) => normName(n) === target)));
}

async function remindModifiers(actor, item) {
  if (!setting("modifierReminders") || !actor || !item) return;
  const mods = modifiersFor(actor, item);
  if (!mods.length) return;
  const rows = mods.map((m) => {
    let txt = plainText(String(m.system.description?.value ?? "").replace(/<p>\s*<em>[\s\S]*?<\/em>\s*<\/p>/gi, ""));
    if (txt.length > 260) txt = `${txt.slice(0, 257)}…`;
    return `<li><strong>${esc(m.name)}</strong>: ${esc(txt)}</li>`;
  }).join("");
  await chat(actor, `<p><strong>${t("Feats.ModifiedBy", { name: esc(item.name) })}</strong></p><ul>${rows}</ul>`);
}

function missingPrereqs(actor, item) {
  const pre = item.flags?.jjk5e?.prereq;
  if (!pre) return [];
  const missing = [];
  const names = new Set(actor.items.map((i) => normName(i.name)));
  for (const group of pre.features ?? []) {
    if (!group.some((n) => names.has(normName(n)))) missing.push(group.join(t("Feats.Or")));
  }
  const techs = new Set([actor.getFlag(MODULE_ID, "technique"), ...actor.items.map((i) => i.flags?.jjk5e?.technique)]
    .filter(Boolean).map(normName));
  for (const group of pre.techniques ?? []) {
    if (!group.some((n) => techs.has(normName(n)))) missing.push(group.join(t("Feats.Or")));
  }
  for (const group of pre.prefixes ?? []) {
    if (!group.some((p) => [...names].some((n) => n.startsWith(normName(p))))) missing.push(group.join(t("Feats.Or")));
  }
  for (const group of pre.options ?? []) {
    const found = group.some((lab) => actor.items.some((i) => new RegExp(`<strong>\\s*${lab.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "i")
      .test(i.system.description?.value ?? "")));
    if (!found) missing.push(group.join(t("Feats.Or")));
  }
  if (pre.ceScore) {
    const score = Number(actor.system.abilities?.[ceAbility(actor)]?.value) || 0;
    if (score < pre.ceScore) missing.push(t("Feats.CEScore", { need: pre.ceScore, have: score }));
  }
  if (pre.level && characterLevel(actor) < pre.level) missing.push(t("Feats.Level", { need: pre.level }));
  if (pre.skill && !(Number(actor.system.skills?.[pre.skill]?.value) >= 1)) missing.push(t("Feats.Skill", { skill: pre.skill }));
  for (const [ab, need] of Object.entries(pre.abilities ?? {})) {
    const have = Number(actor.system.abilities?.[ab]?.value) || 0;
    if (have < need) missing.push(t("Feats.Ability", { ability: ab.toUpperCase(), need, have }));
  }
  // Heavenly Restriction body points & per-category limits
  const cost = Number(item.flags?.jjk5e?.bodyCost) || 0;
  if (cost) {
    const hr = actor.items.find((i) => i.type === "class" && i.system.identifier === "heavenly-restriction");
    const bonus = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.bodyPointBonus) || 0), 0);
    const budget = (Number(hr?.system.levels) || 0) + bonus;
    const used = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.bodyCost) || 0), 0);
    if (used + cost > budget) missing.push(t("Feats.BodyPoints", { used, cost, budget }));
    const cat = item.flags.jjk5e.bodyCategory;
    const limit = Number(actor.system.abilities?.[cat]?.mod) || 0;
    const count = actor.items.filter((i) => i.flags?.jjk5e?.bodyCategory === cat).length;
    if (cat && count + 1 > limit) missing.push(t("Feats.BodyCategory", { ability: cat.toUpperCase(), limit }));
  }
  return missing;
}

function onPreCreateItem(item, data, options, userId) {
  if (userId !== game.user.id || !setting("checkPrereqs")) return;
  const actor = item.parent;
  if (actor?.documentName !== "Actor" || options?.jjk5eSkipPrereq) return;
  const missing = missingPrereqs(actor, item);
  if (missing.length) ui.notifications.warn(t("Feats.Missing", { name: item.name, list: missing.join("; ") }), { permanent: false });
}

/* -------------------------------------------- */
/*  Activation groups (Focus, Fury, Reckless…)   */
/* -------------------------------------------- */

function groupEffects(actor, group) {
  const out = [];
  for (const item of actor.items) for (const e of item.effects ?? []) if (e.flags?.jjk5e?.group === group) out.push(e);
  return out;
}

function activeGroups(actor) {
  const set = new Set();
  for (const item of actor.items) for (const e of item.effects ?? []) {
    if (e.flags?.jjk5e?.group && !e.disabled) set.add(e.flags.jjk5e.group);
  }
  return [...set];
}

async function activateGroup(actor, group) {
  const endless = group === "focus" && actor.items.some((i) => i.name === "Endless Focus");
  const duration = group === "reckless" ? { rounds: 1, turns: 0 } : (endless ? {} : { seconds: 60, rounds: 10 });
  const start = { startTime: game.time?.worldTime ?? 0, startRound: game.combat?.round ?? null, startTurn: game.combat?.turn ?? null };
  for (const e of groupEffects(actor, group)) {
    await e.update({ disabled: false, duration: { ...duration, ...(Object.keys(duration).length ? start : {}) } });
  }
}

async function endGroup(actor, group) {
  for (const e of groupEffects(actor, group)) if (!e.disabled) await e.update({ disabled: true });
}

/* -------------------------------------------- */
/*  Innate Techniques                            */
/* -------------------------------------------- */

const TECH_PACK = "world.jjk5e-techniques";

function techniqueLevel(actor) {
  const classes = actor.items.filter((i) => i.type === "class" && i.system.identifier !== "heavenly-restriction");
  return Math.max(0, ...classes.map((c) => Number(c.system.levels) || 0));
}

function characterLevel(actor) {
  return Number(actor.system?.details?.level) || techniqueLevel(actor) || 0;
}

async function techniqueIndex() {
  const pack = game.packs.get(TECH_PACK);
  if (!pack) {
    ui.notifications.error(t("Notify.NoTechPack"));
    return null;
  }
  const index = await pack.getIndex({ fields: ["flags.jjk5e"] });
  return { pack, index };
}

async function syncTechnique(actor, { notify = true } = {}) {
  const name = actor?.getFlag(MODULE_ID, "technique");
  if (!name) return 0;
  const lvl = techniqueLevel(actor);
  const data = await techniqueIndex();
  if (!data) return 0;
  const owned = new Set(actor.items.filter((i) => i.flags?.jjk5e?.technique === name).map((i) => i.name));
  const ids = data.index
    .filter((e) => e.flags?.jjk5e?.technique === name && (e.flags.jjk5e.level ?? 99) <= lvl && !owned.has(e.name))
    .map((e) => e._id);
  if (!ids.length) return 0;
  const docs = await Promise.all(ids.map((id) => data.pack.getDocument(id)));
  const toCreate = docs.filter(Boolean).map((d) => {
    const obj = d.toObject();
    foundry.utils.setProperty(obj, "_stats.compendiumSource", d.uuid);
    foundry.utils.setProperty(obj, "flags.core.sourceId", d.uuid);
    return obj;
  });
  await actor.createEmbeddedDocuments("Item", toCreate, { jjk5eSkipPrereq: true });
  if (notify) ui.notifications.info(t("Notify.Gained", { name: actor.name, list: toCreate.map((d) => d.name).join(", ") }));
  return toCreate.length;
}

function isHeavenlyOnly(actor) {
  const classes = actor.items.filter((i) => i.type === "class");
  return classes.length > 0 && classes.every((c) => c.system.identifier === "heavenly-restriction");
}

async function chooseTechnique(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  if (!actor.isOwner) return ui.notifications.warn(t("Notify.NotOwner"));
  if (isHeavenlyOnly(actor)) return ui.notifications.warn(t("Notify.HRNoTechnique"));
  const data = await techniqueIndex();
  if (!data) return;
  const names = [...new Set(data.index.map((e) => e.flags?.jjk5e?.technique).filter(Boolean))].sort();
  const current = actor.getFlag(MODULE_ID, "technique");
  const options = names.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}</option>`).join("");
  const content = `<p>${t("Technique.Prompt", { name: esc(actor.name), level: techniqueLevel(actor) })}</p>`
    + `<select name="technique" style="width:100%">${options}</select>`
    + (current ? `<p><em>${t("Technique.Current", { name: esc(current) })}</em></p>` : "");
  const choice = await promptField(t("Technique.Title"), content, "technique");
  if (!choice) return;
  await actor.setFlag(MODULE_ID, "technique", choice);
  if (!actor.getFlag(MODULE_ID, "ceAbility")) await chooseCEAbility(actor);
  const added = await syncTechnique(actor);
  await applyScaling(actor);
  if (!added) ui.notifications.info(t("Notify.TechniqueSet", { name: actor.name, technique: choice }));
}

async function promptCE(mode = "spend", actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const n = await promptNumber(mode === "spend" ? t("CE.SpendTitle") : t("CE.RegainTitle"), t("CE.Amount"));
  if (!n) return;
  return mode === "spend" ? spendCE(actor, n, t("CE.Spent")) : spendCE(actor, -n, t("CE.Regained"));
}

async function shortRestCE(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const classes = actor.items.filter((i) => i.type === "class");
  const maxHD = classes.reduce((tot, c) => tot + (Number(c.system.levels) || 0), 0);
  const cap = Math.floor(maxHD / 2);
  const n = Math.min(cap, await promptNumber(t("CE.ShortRestTitle"), t("CE.ShortRestPrompt", { cap })));
  if (n > 0) await spendCE(actor, -n, t("CE.ShortRestLabel", { n }));
}

async function negativeEmotion(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const pb = Number(actor.system.attributes?.prof) || 2;
  return spendCE(actor, -pb, t("CE.NegativeEmotion"));
}

/* -------------------------------------------- */
/*  Level scaling                                */
/* -------------------------------------------- */

const CE_TOKEN = "max(@abilities.wis.mod, @abilities.cha.mod)";

async function applyScaling(actor) {
  if (!actor?.isOwner) return;
  const lvl = techniqueLevel(actor) || characterLevel(actor);
  for (const item of actor.items) {
    const table = item.flags?.jjk5e?.dmgScale;
    if (!table) continue;
    const src = item.toObject().system.activities ?? {};
    const update = {};
    for (const [aid, tiers] of Object.entries(table)) {
      const parts = src[aid]?.damage?.parts;
      if (!parts?.length) continue;
      const tier = tiers.filter(([l]) => l <= lvl).pop();
      const m = tier && /^(\d+)d(\d+)$/.exec(tier[1]);
      if (!m) continue;
      if (parts[0].number === Number(m[1]) && parts[0].denomination === Number(m[2])) continue;
      parts[0].number = Number(m[1]);
      parts[0].denomination = Number(m[2]);
      update[`system.activities.${aid}.damage.parts`] = parts;
    }
    if (Object.keys(update).length) await item.update(update);
  }
  const rollData = actor.getRollData();
  for (const item of actor.items) {
    for (const effect of item.effects ?? []) {
      const lt = effect.flags?.jjk5e?.levelTable;
      if (lt) {
        const cls = actor.items.find((i) => i.type === "class" && i.system.identifier === lt.class);
        const lvl = lt.class === "*" ? characterLevel(actor) : (Number(cls?.system.levels) || 0);
        const row = lt.table.filter(([l]) => l <= lvl).pop();
        const v = String(row ? row[1] : 0);
        const keys = lt.keys ?? null;
        const changes = effChanges(effect).map((c) => (!keys || keys.includes(c.key) ? { ...c, value: v } : c));
        if (changes.some((c, i) => c.value !== effChanges(effect)[i].value)) await effect.update(fxChanges(changes));
      }
    }
  }
  for (const item of actor.items) {
    for (const effect of item.effects ?? []) {
      const key = effect.flags?.jjk5e?.scaleKey;
      if (!key) continue;
      const sv = foundry.utils.getProperty(rollData, `scale.${key}`);
      const value = Number(sv?.value ?? sv);
      if (!Number.isFinite(value)) continue;
      const changes = effChanges(effect).map((c) => ({ ...c, value: String(value) }));
      if (changes.some((c, i) => c.value !== effChanges(effect)[i].value)) await effect.update(fxChanges(changes));
    }
  }
  const ab = actor.getFlag(MODULE_ID, "ceAbility");
  const abTok = `@abilities.${ab ?? ceAbility(actor)}.mod`;
  const bonusParts = actor.items.map((i) => i.flags?.jjk5e?.ceMaxBonus).filter((b) => b !== undefined && b !== null && b !== 0)
    .map((b) => (typeof b === "number" ? String(b) : `(${String(b).split(CE_TOKEN).join(abTok)})`));
  for (const pool of actor.items.filter((i) => i.flags?.jjk5e?.cePool)) {
    const srcMax = String(pool.toObject().system.uses?.max ?? "");
    let base = pool.flags.jjk5e.baseMax ?? srcMax;
    if (ab) base = base.split(CE_TOKEN).join(`@abilities.${ab}.mod`);
    const desired = bonusParts.length ? `${base} + ${bonusParts.join(" + ")}` : base;
    if (desired !== srcMax || pool.flags.jjk5e.baseMax !== base) {
      await pool.update({ "system.uses.max": desired, "flags.jjk5e.baseMax": base });
    }
  }
  if (ab) {
    for (const item of actor.items) {
      if (item.flags?.jjk5e?.cePool) continue;
      const json = JSON.stringify(item.toObject().system);
      if (!json.includes(CE_TOKEN)) continue;
      await item.update({ system: JSON.parse(json.split(CE_TOKEN).join(`@abilities.${ab}.mod`)) });
    }
  }
  await applyCEEffects(actor);
  await syncResource(actor);
}

const UD_NAMES = ["unarmored defense", "restrained body", "hard shell", "integrated armor"];

/** Effects whose values depend on the CE modifier, and the CE score bonus (Immense Cursed Energy). */
async function applyCEEffects(actor) {
  const ab = ceAbility(actor);
  const mod = `@abilities.${ab}.mod`;
  const hasUD = actor.items.some((i) => UD_NAMES.includes(i.name.toLowerCase()) && i.flags?.jjk5e);
  for (const item of actor.items) {
    for (const effect of item.effects ?? []) {
      const tpls = effect.flags?.jjk5e?.ceChanges;
      let changes = effChanges(effect);
      let dirty = false;
      if (tpls?.length) {
        changes = tpls.map((c) => ({ key: c.key, mode: c.mode, priority: null,
          value: c.tpl.replace("{CEHALF}", hasUD ? `ceil(${mod} / 2)` : mod).replace("{CE}", mod) }));
        dirty = JSON.stringify(changes.map((c) => c.value)) !== JSON.stringify(effChanges(effect).map((c) => c.value));
      } else if (effChanges(effect).some((c) => String(c.value).includes(CE_TOKEN))) {
        changes = effChanges(effect).map((c) => ({ ...c, value: String(c.value).split(CE_TOKEN).join(mod) }));
        dirty = true;
      }
      if (dirty) await effect.update(fxChanges(changes));
    }
    const bonus = Number(item.flags?.jjk5e?.ceScoreBonus) || 0;
    if (!bonus) continue;
    const key = `system.abilities.${ab}.value`;
    const existing = item.effects?.find((e) => e.flags?.jjk5e?.kind === "ceScore");
    const data = { name: `${item.name}: CE score +${bonus}`, img: item.img, transfer: true, disabled: false,
      changes: [{ key, mode: 2, value: String(bonus), priority: null }], flags: { jjk5e: { kind: "ceScore" } } };
    if (!existing) await item.createEmbeddedDocuments("ActiveEffect", [fxData(data)]);
    else if (effChanges(existing)[0]?.key !== key) await existing.update(fxChanges(data.changes));
  }
}

async function chooseCEAbility(actor) {
  actor = requireActor(actor);
  if (!actor) return null;
  const a = actor.system.abilities;
  const current = ceAbility(actor);
  const content = `<p>${t("CE.AbilityPrompt", { name: esc(actor.name) })}</p>`
    + `<select name="ability" style="width:100%">`
    + `<option value="wis" ${current === "wis" ? "selected" : ""}>${t("Common.Wisdom")} (${a.wis?.mod ?? 0})</option>`
    + `<option value="cha" ${current === "cha" ? "selected" : ""}>${t("Common.Charisma")} (${a.cha?.mod ?? 0})</option></select>`;
  const choice = await promptField(t("CE.AbilityTitle"), content, "ability");
  if (!choice) return null;
  const old = actor.getFlag(MODULE_ID, "ceAbility");
  await actor.update({ "system.attributes.spellcasting": choice, [`flags.${MODULE_ID}.ceAbility`]: choice });
  if (old && old !== choice) {
    const from = `@abilities.${old}.mod`;
    for (const item of actor.items) {
      const json = JSON.stringify(item.toObject().system);
      if (item.flags?.jjk5e && json.includes(from)) {
        await item.update({ system: JSON.parse(json.split(from).join(`@abilities.${choice}.mod`)) });
      }
      const bm = item.flags?.jjk5e?.baseMax;
      if (bm?.includes(from)) await item.update({ "flags.jjk5e.baseMax": bm.split(from).join(`@abilities.${choice}.mod`) });
    }
  }
  await applyScaling(actor);
  ui.notifications.info(t("Notify.CEAbility", { name: actor.name, ability: choice.toUpperCase() }));
  return choice;
}

/* -------------------------------------------- */
/*  Black Flash & The Zone                       */
/* -------------------------------------------- */

const handledRolls = new WeakSet();

async function onAttackRoll(rolls, subject) {
  if (!setting("blackFlash")) return;
  const roll = Array.isArray(rolls) ? rolls[0] : rolls;
  if (!roll || handledRolls.has(roll)) return;
  handledRolls.add(roll);
  const activity = subject?.activity ?? subject;
  const actor = activity?.actor ?? activity?.item?.actor ?? activity?.parent?.actor;
  if (!actor?.isOwner) return;
  if (!roll.isCritical) {
    if (actor.getFlag(MODULE_ID, "pendingBlackFlash")) await actor.unsetFlag(MODULE_ID, "pendingBlackFlash");
    return;
  }
  if (actor.type !== "character" || isHeavenlyOnly(actor)) return;
  const kind = activity?.attack?.type?.value ?? activity?.actionType;
  if (kind && !["melee", "mwak", "msak"].includes(kind)) return;
  const zone = zoneEffect(actor);
  const stacks = Number(zone?.flags?.jjk5e?.zone) || 0;
  const bonusRange = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.blackFlashRange) || 0), 0);
  const target = Math.max(2, 20 - stacks - bonusRange);
  const check = await new Roll("1d20").evaluate();
  const success = check.total >= target;
  const Chat = docClass("ChatMessage");
  await check.toMessage({
    speaker: Chat.getSpeaker({ actor }),
    flavor: `<strong>${t("BlackFlash.Check")}</strong> (${t("BlackFlash.Needs", { target })})`
      + (success ? `<h3 style="color:#b00;text-align:center">⚡ BLACK FLASH ⚡</h3><p>${t("BlackFlash.Success")}</p>` : "")
  });
  if (!success) return;
  if (setting("blackFlashDamage")) await actor.setFlag(MODULE_ID, "pendingBlackFlash", true);
  const next = stacks + 1;
  await setKindEffect(actor, "zone", {
    name: `${t("Zone.Name")}${next > 1 ? ` ×${next}` : ""}`, img: `${ICONS}/zone.svg`,
    duration: { rounds: 10, seconds: 60 },
    changes: [
      { key: "flags.dnd5e.weaponCriticalThreshold", mode: 3, value: String(20 - next) },
      { key: "flags.dnd5e.spellCriticalThreshold", mode: 3, value: String(20 - next) }
    ],
    description: `<p>${t("Zone.Description")}</p>`,
    flags: { jjk5e: { zone: next } }
  });
  const burnout = actor.effects.filter((e) => e.flags?.jjk5e?.kind === "burnout" || e.flags?.jjk5e?.burnout).map((e) => e.id);
  if (burnout.length) await actor.deleteEmbeddedDocuments("ActiveEffect", burnout);
  const ro = Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0;
  if (ro > 0) await setReducedOutput(actor, ro - 1);
}

function traitChoice(actor, flag) {
  for (const item of actor.items) {
    const e = item.effects?.find((x) => x.flags?.jjk5e?.[flag] && !x.disabled);
    if (e) return e.flags.jjk5e[flag];
  }
  return null;
}

function addPart(config, part) {
  const roll = config?.rolls?.[0];
  if (!roll) return;
  roll.parts ??= [];
  roll.parts.push(part);
}

function onPreRollAttack(config) {
  const actor = config?.subject?.actor ?? config?.subject?.item?.actor;
  if (!actor) return;
  if (setting("zoneAdvantage") && zoneEffect(actor) && !zoneEffect(actor).disabled) config.advantage = true;
  const melee = (config?.subject?.attack?.type?.value ?? config?.subject?.actionType) === "melee"
    || ["mwak", "msak"].includes(config?.subject?.actionType);
  if (melee && activeGroups(actor).includes("reckless")) config.advantage = true;
  if (config?.subject?.item?.flags?.jjk5e?.rawCE && traitChoice(actor, "ceTrait") === "rough") addPart(config, "1");
  applySureHit(actor, config);
}

function rawCEDamageBonus(actor) {
  const mastery = traitChoice(actor, "ceMastery");
  const trait = traitChoice(actor, "ceTrait");
  const parts = [];
  if (mastery === "rough") parts.push(`2 + @abilities.${ceAbility(actor)}.mod`);
  else if (trait === "rough") parts.push("2");
  if (trait === "elemental") parts.push("@prof");
  return parts;
}

function onPreRollDamage(config) {
  const actor = config?.subject?.actor ?? config?.subject?.item?.actor;
  if (actor && config?.subject?.item?.flags?.jjk5e?.rawCE) rawCEDamageBonus(actor).forEach((p) => addPart(config, p));
  if (!setting("blackFlashDamage")) return;
  if (!actor?.getFlag?.(MODULE_ID, "pendingBlackFlash")) return;
  const critical = config.isCritical === true || (config.rolls ?? []).some((r) => r.options?.isCritical === true);
  if (!critical) return;
  for (const r of config.rolls ?? []) {
    r.options ??= {};
    r.options.critical = { ...(r.options.critical ?? {}), multiplier: 3 };
  }
  config.critical = { ...(config.critical ?? {}), multiplier: 3 };
  actor.unsetFlag(MODULE_ID, "pendingBlackFlash");
  chat(actor, `<p><strong>⚡ Black Flash</strong>: ${t("BlackFlash.Damage")}</p>`);
}

/* -------------------------------------------- */
/*  Domain Expansion & Technique Burnout         */
/* -------------------------------------------- */

async function openDomain(actor, item) {
  if (!actor?.isOwner || !setting("domainTracking")) return;
  await setKindEffect(actor, "domain", {
    name: item.name, img: `${ICONS}/domain.svg`, duration: { rounds: 10, seconds: 60 },
    description: `<p>${t("Domain.Description")}</p>`,
    flags: { jjk5e: { domainOpen: true } }
  });
}

async function closeDomain(actor) {
  const eff = actor.effects.find((e) => e.flags?.jjk5e?.kind === "domain" || e.flags?.jjk5e?.domainOpen);
  if (eff) await eff.delete();
}

async function onDeleteEffect(effect, options, userId) {
  if (userId !== game.user.id) return;
  if (!(effect.flags?.jjk5e?.domainOpen || effect.flags?.jjk5e?.kind === "domain")) return;
  if (!setting("domainTracking")) return;
  const actor = effect.parent;
  if (actor?.documentName !== "Actor") return;
  await setKindEffect(actor, "burnout", {
    name: t("Burnout.Name"), img: `${ICONS}/burnout.svg`, duration: { rounds: 10, seconds: 60 },
    changes: [{ key: "system.attributes.exhaustion", mode: 2, value: "2" }],
    description: `<p>${t("Burnout.Description")}</p>`,
    flags: { jjk5e: { burnout: true } }
  });
  ui.notifications.info(t("Notify.Burnt", { name: actor.name }));
}

/* -------------------------------------------- */
/*  Maximum / Reduced Output                     */
/* -------------------------------------------- */

async function setReducedOutput(actor, level) {
  level = clamp(Number(level) || 0, 0, 9);
  await actor.setFlag(MODULE_ID, "reducedOutput", level);
  await setKindEffect(actor, "reduced", level ? {
    name: `${t("Output.Reduced")} ${level}`, img: `${ICONS}/reduced.svg`,
    description: `<p><strong>${RO_ROWS[level]}</strong></p><p>${t("Output.ReducedDescription")}</p>`
  } : null);
  return level;
}

async function maximumOutput(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const ro = Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0;
  const base = await promptNumber(t("Output.MaxTitle"), t("Output.MaxPrompt"), 5);
  if (!base) return;
  if (base < 3) return ui.notifications.warn(t("Output.TooLow"));
  if (base < 5) ui.notifications.info(t("Output.ShikigamiOnly"));
  const combat = game.combat;
  const key = combat ? `${combat.id}:${combat.round}` : null;
  const last = actor.getFlag(MODULE_ID, "maxOutputRound");
  if (key && last === key) {
    const dc = 15 + 2 * ro;
    const r = await new Roll(`1d20 + ${ceMod(actor)}`).evaluate();
    await r.toMessage({ speaker: docClass("ChatMessage").getSpeaker({ actor }), flavor: t("Output.Check", { dc }) });
    if (r.total < dc) {
      await setReducedOutput(actor, ro + 1);
      ui.notifications.warn(t("Output.GainedRO", { level: ro + 1 }));
    }
  }
  if (key) await actor.setFlag(MODULE_ID, "maxOutputRound", key);
  const extra = Math.ceil(base / 2) + 2 * ro;
  await spendCE(actor, extra, t("Output.Max"));
  await chat(actor, `<p><strong>${t("Output.Max")}</strong> (+${extra} CE)</p>${t("Output.Benefits")}`);
}

/* -------------------------------------------- */
/*  Soul Awareness                               */
/* -------------------------------------------- */

const SOUL_ABILITIES = [
  "Minor Soul Perception", "Lesser Soul Guard", "Medium Soul Perception", "Soul Harming", "Soul Knowledge",
  "Major Soul Perception", "Soul Anchoring", "Greater Soul Guard", "Greater Soul Harming", "Soul Removal"
];

async function setSoulAwareness(actor, level) {
  level = clamp(Number(level) || 0, 0, 10);
  await actor.setFlag(MODULE_ID, "soulAwareness", level);
  const list = SOUL_ABILITIES.slice(0, level).map((n, i) => `<li>${i + 1}. ${n}</li>`).join("");
  await setKindEffect(actor, "soul", level ? {
    name: `${t("Soul.Name")} ${level}`, img: `${ICONS}/soul.svg`,
    description: `<ul>${list}</ul><p>${t("Soul.Description")}</p>`
  } : null);
  return level;
}

/* -------------------------------------------- */
/*  Limb Damage                                  */
/* -------------------------------------------- */

const LIMBS = [
  { key: "rleg", mult: 1, roll: 1 }, { key: "lleg", mult: 1, roll: 2 }, { key: "rarm", mult: 1, roll: 3 },
  { key: "larm", mult: 1, roll: 4 }, { key: "torso", mult: 2, roll: 5 }, { key: "head", mult: 2, roll: 6 }
];

function limbThreshold(actor, limb) {
  const con = Math.max(1, Number(actor.system.abilities?.con?.mod) || 0);
  return con * characterLevel(actor) * limb.mult;
}

async function setLimb(actor, key, status) {
  const limb = LIMBS.find((l) => l.key === key);
  if (!limb) return;
  const limbs = { ...(actor.getFlag(MODULE_ID, "limbs") ?? {}) };
  limbs[key] = status;
  await actor.setFlag(MODULE_ID, "limbs", limbs);
  if (status === "ok") return setKindEffect(actor, `limb:${key}`, null);
  const name = `${t(`Limb.${key}`)}: ${t(`Limb.${status}`)}`;
  const data = { name, img: `${ICONS}/limb.svg`, changes: [], statuses: [], description: `<p>${t(`Limb.Effect.${key}.${status}`)}</p>` };
  if (key === "rleg" || key === "lleg") data.changes.push({ key: "system.attributes.movement.walk", mode: 1, value: "0.5" });
  if (key === "torso" && status === "broken") {
    const max = Number(actor.system.attributes?.hp?.max) || 0;
    data.changes.push({ key: "system.attributes.hp.bonuses.overall", mode: 2, value: String(-Math.floor(max / 2)) });
  }
  if (key === "head" && status === "broken") data.statuses.push("unconscious");
  if ((key === "torso" || key === "head") && status === "lost") data.statuses.push("dead");
  await setKindEffect(actor, `limb:${key}`, data);
  await chat(actor, `<p><strong>${esc(actor.name)}</strong> — ${esc(name)}</p><p>${t(`Limb.Effect.${key}.${status}`)}</p>`);
}

async function rollLimb(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const worldTable = game.tables?.find((tb) => tb.flags?.jjk5e?.worldCopy && /limb/i.test(tb.name));
  if (worldTable) return worldTable.draw();
  const pack = game.packs.get("world.jjk5e-tables");
  const entry = pack && (await pack.getIndex()).find((e) => /limb/i.test(e.name));
  if (entry) {
    const table = await pack.getDocument(entry._id);
    return table.draw();
  }
  const r = await new Roll("1d6").evaluate();
  const limb = LIMBS.find((l) => l.roll === r.total);
  await r.toMessage({ speaker: docClass("ChatMessage").getSpeaker({ actor }), flavor: `${t("Limb.Roll")}: ${t(`Limb.${limb.key}`)}` });
}

/* -------------------------------------------- */
/*  Summons (shikigami, ink creatures, …)        */
/* -------------------------------------------- */

const SUMMON_ALIASES = { "ink wolf": "Wolf", "ink crow": "Giant Eagle", "killer whale": "Killer Whale" };
const SUMMON_FOLDER = "JJK Summons";

async function findSummonSource(name) {
  const n = name.trim().toLowerCase();
  const alias = (SUMMON_ALIASES[n] ?? name).toLowerCase();
  const world = game.actors.find((a) => [n, alias].includes(a.name.toLowerCase()));
  if (world) return { actor: world };
  const packs = [...(game.packs.contents ?? game.packs.values())].filter((p) => p.documentName === "Actor")
    .sort((a, b) => (b.collection.startsWith("dnd5e.") ? 1 : 0) - (a.collection.startsWith("dnd5e.") ? 1 : 0));
  for (const pack of packs) {
    const entry = (await pack.getIndex()).find((e) => [n, alias].includes(e.name.toLowerCase()));
    if (entry) return { pack, id: entry._id };
  }
  return null;
}

async function gmSummon({ actorUuid, name, count = 1, userId, sceneId, stats = null }) {
  const src = await findSummonSource(name);
  if (!src) return ui.notifications.warn(t("Summon.NotFound", { name }));
  let actor = src.actor;
  if (!actor) {
    let folder = game.folders.find((f) => f.type === "Actor" && f.name === SUMMON_FOLDER);
    if (!folder) folder = await docClass("Folder").create({ name: SUMMON_FOLDER, type: "Actor" });
    actor = await game.actors.importFromCompendium(src.pack, src.id, { folder: folder.id });
  }
  if (userId && actor.ownership?.[userId] !== 3) await actor.update({ [`ownership.${userId}`]: 3 });
  const scene = game.scenes.get(sceneId) ?? canvas.scene;
  if (!scene) return;
  const summoner = await fromUuid(actorUuid);
  const baseId = summoner?.isToken ? summoner.token?.actorId : summoner?.id;
  const sTok = scene.tokens.find((tk) => (summoner?.isToken && tk.id === summoner.token?.id) || tk.actorId === baseId);
  const grid = scene.grid?.size ?? 100;
  const tokens = [];
  for (let i = 0; i < count; i++) {
    const x = sTok ? sTok.x + (Number(sTok.width) || 1) * grid + i * grid : grid * (i + 1);
    const y = sTok ? sTok.y : grid;
    const extra = { x, y, disposition: sTok?.disposition ?? 1, flags: { jjk5e: { summonedBy: actorUuid } } };
    if (stats) {
      extra.actorLink = false;
      extra.delta = { system: { attributes: {
        hp: { value: stats.hp, max: stats.hp }, ac: { calc: "flat", flat: stats.ac } } } };
    }
    const td = await actor.getTokenDocument(extra);
    tokens.push(td.toObject());
  }
  await scene.createEmbeddedDocuments("Token", tokens);
}

async function gmDismiss({ actorUuid, sceneId }) {
  const scene = game.scenes.get(sceneId) ?? canvas.scene;
  if (!scene) return;
  const ids = scene.tokens.filter((tk) => tk.flags?.jjk5e?.summonedBy === actorUuid).map((tk) => tk.id);
  if (ids.length) await scene.deleteEmbeddedDocuments("Token", ids);
}

function viaGM(action, payload) {
  if (game.user.isGM) return action === "summon" ? gmSummon(payload) : gmDismiss(payload);
  const gm = game.users.activeGM ?? game.users.find((u) => u.isGM && u.active);
  if (!gm) return ui.notifications.warn(t("Notify.NoGM"));
  game.socket.emit(`module.${MODULE_ID}`, { action, payload, gm: gm.id });
}

async function summon(actor, name, count = 1) {
  actor = requireActor(actor);
  if (!actor || !name) return;
  return viaGM("summon", { actorUuid: actor.uuid, name, count: clamp(Number(count) || 1, 1, 20), userId: game.user.id, sceneId: canvas.scene?.id });
}

async function dismissSummons(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  return viaGM("dismiss", { actorUuid: actor.uuid, sceneId: canvas.scene?.id });
}

/* -------------------------------------------- */
/*  Effect expiry (when Times Up is not active)  */
/* -------------------------------------------- */

async function expireEffects() {
  if (!game.user.isGM || !setting("autoExpire") || game.modules.get("times-up")?.active) return;
  const actors = new Set();
  game.combat?.combatants?.forEach((c) => c.actor && actors.add(c.actor));
  canvas?.scene?.tokens?.forEach((tk) => tk.actor && actors.add(tk.actor));
  game.actors?.forEach((a) => a.type === "character" && actors.add(a));
  for (const actor of actors) {
    const ids = actor.effects.filter((e) => {
      const kind = e.flags?.jjk5e?.kind;
      if (!["zone", "burnout", "domain"].includes(kind)) return false;
      const rem = e.duration?.remaining;
      return rem !== null && rem !== undefined && rem <= 0;
    }).map((e) => e.id);
    for (const id of ids) await actor.effects.get(id)?.delete();
    for (const item of actor.items) for (const e of item.effects ?? []) {
      if (!e.flags?.jjk5e?.group || e.disabled) continue;
      const rem = e.duration?.remaining;
      if (rem !== null && rem !== undefined && rem <= 0) await e.update({ disabled: true });
    }
  }
}

/* -------------------------------------------- */
/*  JJK Panel                                    */
/* -------------------------------------------- */

const PANELS = new Map();

function panelHTML(actor) {
  const pool = findPool(actor);
  const value = pool ? poolValue(pool) : 0;
  const max = pool ? poolMax(pool) : 0;
  const pct = max ? Math.round((value / max) * 100) : 0;
  const tech = actor.getFlag(MODULE_ID, "technique");
  const ab = actor.getFlag(MODULE_ID, "ceAbility");
  const ro = Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0;
  const soul = Number(actor.getFlag(MODULE_ID, "soulAwareness")) || 0;
  const limbs = actor.getFlag(MODULE_ID, "limbs") ?? {};
  const zone = zoneEffect(actor);
  const zoneStacks = Number(zone?.flags?.jjk5e?.zone) || 0;
  const hr = isHeavenlyOnly(actor);
  const statusRow = (on, label, action) => `<span class="jjk-chip ${on ? "on" : ""}">${label}${on && action
    ? ` <a data-action="${action}" title="${t("Common.End")}"><i class="fas fa-times"></i></a>` : ""}</span>`;
  const limbRows = LIMBS.map((l) => {
    const st = limbs[l.key] ?? "ok";
    const btn = (s) => `<button type="button" class="${st === s ? "active" : ""}" data-action="limb" data-limb="${l.key}" data-status="${s}">${t(`Limb.${s}`)}</button>`;
    return `<tr class="limb-${st}"><td>${t(`Limb.${l.key}`)}</td><td class="num">${limbThreshold(actor, l)}</td>`
      + `<td class="num">${limbThreshold(actor, l) * 2}</td><td class="btns">${btn("ok")}${btn("broken")}${btn("lost")}</td></tr>`;
  }).join("");
  const soulList = SOUL_ABILITIES.slice(0, soul).map((n) => `<li>${n}</li>`).join("");
  const suggestions = [...new Set([...Object.keys(SUMMON_ALIASES).map((k) => k.replace(/\b\w/g, (c) => c.toUpperCase())),
    ...game.actors.filter((a) => a.folder?.name === SUMMON_FOLDER || a.folder?.name === "JJK Shikigami").map((a) => a.name)])]
    .map((n) => `<option value="${esc(n)}"></option>`).join("");

  return `
  <section class="jjk-panel">
    <header class="jjk-head">
      <img src="${ICONS}/ce.svg" alt="">
      <div>
        <div class="jjk-name">${esc(actor.name)}</div>
        <div class="jjk-sub">${hr ? t("Panel.HR") : `${t("Panel.Technique")}: <strong>${esc(tech ?? t("Panel.None"))}</strong>`}
          ${hr ? "" : ` · ${t("Panel.CEAbility")}: <strong>${ab ? ab.toUpperCase() : "?"}</strong>`}</div>
      </div>
      <div class="jjk-head-btns">
        <button type="button" data-action="pointBuy" title="${t("PointBuy.Title")}"><i class="fas fa-dice-d20"></i></button>
        ${hr ? "" : `<button type="button" data-action="chooseTechnique" title="${t("Panel.ChooseTechnique")}"><i class="fas fa-hand-sparkles"></i></button>
        <button type="button" data-action="ceAbility" title="${t("Panel.SetAbility")}"><i class="fas fa-brain"></i></button>`}</div>
    </header>

    ${pool ? `<fieldset><legend>${t("CE.Name")}</legend>
      <div class="jjk-bar"><div class="fill" style="width:${pct}%"></div><span>${value} / ${max}</span></div>
      <div class="jjk-row">
        <button type="button" data-action="ceMinus">−1</button><button type="button" data-action="cePlus">+1</button>
        <button type="button" data-action="ceSpend">${t("Panel.Spend")}</button><button type="button" data-action="ceRegain">${t("Panel.Regain")}</button>
        <button type="button" data-action="negEmotion" title="${t("CE.NegativeEmotion")}"><i class="fas fa-face-angry"></i></button>
        <button type="button" data-action="shortRest" title="${t("CE.ShortRestTitle")}"><i class="fas fa-bed"></i></button>
      </div></fieldset>` : (hr ? "" : `<p class="jjk-note">${t("Panel.NoPool")}</p>`)}

    <fieldset><legend>${t("Panel.Status")}</legend>
      <div class="jjk-row">
        ${statusRow(domainOpen(actor), t("Domain.Open"), "closeDomain")}
        ${statusRow(inBurnout(actor), t("Burnout.Name"), "clearBurnout")}
        ${statusRow(!!zone, zone ? `${t("Zone.Name")} ×${zoneStacks}` : t("Zone.Name"), "clearZone")}
        ${statusRow(!!actor.getFlag(MODULE_ID, "pendingBlackFlash"), "Black Flash ×3", "clearBF")}
        ${activeGroups(actor).map((g) => `<span class="jjk-chip on">${t(`Group.${g}`)} <a data-action="endGroup" data-group="${g}" title="${t("Common.End")}"><i class="fas fa-times"></i></a></span>`).join("")}
      </div></fieldset>

    ${hr ? "" : `<fieldset><legend>${t("Output.Title")}</legend>
      <div class="jjk-row">
        <button type="button" data-action="maxOutput"><i class="fas fa-bolt"></i> ${t("Output.Max")}</button>
        <span class="jjk-lbl">${t("Output.Reduced")}</span>
        <button type="button" data-action="roDown">−</button><strong class="jjk-num">${ro}</strong><button type="button" data-action="roUp">+</button>
      </div>
      ${ro ? `<p class="jjk-note">${RO_ROWS[ro]}</p>` : ""}</fieldset>`}

    <fieldset><legend>${t("Soul.Name")}</legend>
      <div class="jjk-row"><button type="button" data-action="soulDown">−</button><strong class="jjk-num">${soul}</strong>
      <button type="button" data-action="soulUp">+</button></div>
      ${soul ? `<ul class="jjk-list">${soulList}</ul>` : ""}</fieldset>

    <fieldset><legend>${t("Limb.Title")}</legend>
      <table class="jjk-limbs"><thead><tr><th></th><th>${t("Limb.Broken")}</th><th>${t("Limb.Lost")}</th><th></th></tr></thead>
      <tbody>${limbRows}</tbody></table>
      <div class="jjk-row"><button type="button" data-action="limbRoll"><i class="fas fa-dice-d6"></i> ${t("Limb.Roll")}</button></div>
    </fieldset>

    <fieldset><legend>${t("Summon.Title")}</legend>
      <div class="jjk-row">
        <input type="text" name="summonName" list="jjk-summon-${actor.id}" placeholder="${t("Summon.Placeholder")}">
        <datalist id="jjk-summon-${actor.id}">${suggestions}</datalist>
        <input type="number" name="summonCount" value="1" min="1" max="20" class="jjk-count">
        <button type="button" data-action="summon"><i class="fas fa-paw"></i></button>
        <button type="button" data-action="dismiss" title="${t("Summon.Dismiss")}"><i class="fas fa-ghost"></i></button>
      </div>
      <p class="jjk-note">${t("Summon.Hint")}</p></fieldset>
  </section>`;
}

const PANEL_ACTIONS = {
  ceMinus: (actor) => spendCE(actor, 1, t("CE.Spent")),
  cePlus: (actor) => spendCE(actor, -1, t("CE.Regained")),
  ceSpend: (actor) => promptCE("spend", actor),
  ceRegain: (actor) => promptCE("regain", actor),
  negEmotion: (actor) => negativeEmotion(actor),
  shortRest: (actor) => shortRestCE(actor),
  chooseTechnique: (actor) => chooseTechnique(actor),
  ceAbility: (actor) => chooseCEAbility(actor),
  pointBuy: (actor) => pointBuy(actor),
  closeDomain: (actor) => closeDomain(actor),
  clearBurnout: async (actor) => {
    const ids = actor.effects.filter((e) => e.flags?.jjk5e?.kind === "burnout" || e.flags?.jjk5e?.burnout).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids);
  },
  clearZone: async (actor) => { const z = zoneEffect(actor); if (z) await z.delete(); },
  clearBF: (actor) => actor.unsetFlag(MODULE_ID, "pendingBlackFlash"),
  endGroup: (actor, target) => endGroup(actor, target.dataset.group),
  maxOutput: (actor) => maximumOutput(actor),
  roDown: (actor) => setReducedOutput(actor, (Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0) - 1),
  roUp: (actor) => setReducedOutput(actor, (Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0) + 1),
  soulDown: (actor) => setSoulAwareness(actor, (Number(actor.getFlag(MODULE_ID, "soulAwareness")) || 0) - 1),
  soulUp: (actor) => setSoulAwareness(actor, (Number(actor.getFlag(MODULE_ID, "soulAwareness")) || 0) + 1),
  limb: (actor, target) => setLimb(actor, target.dataset.limb, target.dataset.status),
  limbRoll: (actor) => rollLimb(actor),
  summon: (actor, target, root) => summon(actor, root.querySelector("[name=summonName]")?.value,
    root.querySelector("[name=summonCount]")?.valueAsNumber),
  dismiss: (actor) => dismissSummons(actor)
};

function makePanelClass() {
  const Base = foundry.applications?.api?.ApplicationV2;
  if (!Base) return null;
  const actions = {};
  for (const [name, fn] of Object.entries(PANEL_ACTIONS)) {
    actions[name] = async function (event, target) {
      try { await fn(this.actor, target, this.element); } catch (err) { console.error(err); ui.notifications.error(String(err.message ?? err)); }
      this.render();
    };
  }
  return class JJKPanel extends Base {
    static DEFAULT_OPTIONS = {
      classes: ["jjk5e-panel-app"],
      window: { icon: "fas fa-yin-yang", resizable: true },
      position: { width: 460, height: "auto" },
      actions
    };

    constructor(actor, options = {}) {
      super(foundry.utils.mergeObject({ id: `jjk5e-panel-${actor.uuid.replace(/\./g, "-")}` }, options));
      this.actor = actor;
    }

    get title() { return `JJK — ${this.actor.name}`; }

    async _renderHTML() { return panelHTML(this.actor); }

    _replaceHTML(result, content) { content.innerHTML = result; }

    _onClose(options) {
      PANELS.delete(this.actor.uuid);
      return super._onClose?.(options);
    }
  };
}

let JJKPanelClass = null;

function openPanel(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  if (!actor.isOwner) return ui.notifications.warn(t("Notify.NotOwner"));
  JJKPanelClass ??= makePanelClass();
  if (!JJKPanelClass) return ui.notifications.error("ApplicationV2 not available.");
  let app = PANELS.get(actor.uuid);
  if (!app) {
    app = new JJKPanelClass(actor);
    PANELS.set(actor.uuid, app);
  }
  syncResource(actor);
  return app.render({ force: true });
}

function refreshPanels(actor) {
  if (!actor) return;
  const app = PANELS.get(actor.uuid);
  if (app?.rendered) app.render();
}

function addHeaderButton(app, root) {
  if (!setting("headerButton")) return;
  const actor = app.actor ?? app.document;
  if (!actor || actor.documentName !== "Actor" || actor.type !== "character" || !actor.isOwner) return;
  root = root instanceof HTMLElement ? root : root?.[0];
  const el = app.element instanceof HTMLElement ? app.element : app.element?.[0] ?? root;
  const header = el?.querySelector?.(".window-header") ?? root?.closest?.(".app, .application")?.querySelector(".window-header");
  if (!header || header.querySelector(".jjk5e-open")) return;
  const isV2 = header.tagName === "HEADER" && !!el?.classList?.contains("application");
  const btn = document.createElement(isV2 ? "button" : "a");
  btn.className = isV2 ? "header-control icon jjk5e-open" : "header-button control jjk5e-open";
  btn.type = isV2 ? "button" : undefined;
  btn.title = t("Panel.Open");
  btn.innerHTML = isV2 ? `<i class="fas fa-yin-yang"></i>` : `<i class="fas fa-yin-yang"></i>JJK`;
  btn.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); openPanel(actor); });
  const anchor = header.querySelector('[data-action="close"], .close, .header-button.close');
  if (anchor) anchor.before(btn);
  else header.append(btn);
}

/* -------------------------------------------- */
/*  Init / Ready                                 */
/* -------------------------------------------- */

Hooks.once("init", () => {
  const reg = (key, type, def, extra = {}) => game.settings.register(MODULE_ID, key, {
    name: `JJK5E.Settings.${key}.Name`, hint: `JJK5E.Settings.${key}.Hint`,
    scope: "world", config: true, type, default: def, ...extra
  });
  game.settings.register(MODULE_ID, "importedVersion", { scope: "world", config: false, type: String, default: "" });
  reg("autoSpendCE", Boolean, true);
  reg("ceChat", Boolean, true);
  reg("ceResource", String, "tertiary", {
    choices: { none: "JJK5E.Settings.ceResource.None", primary: "JJK5E.Settings.ceResource.Primary",
      secondary: "JJK5E.Settings.ceResource.Secondary", tertiary: "JJK5E.Settings.ceResource.Tertiary" }
  });
  reg("autoTokenBar", Boolean, true);
  reg("blackFlash", Boolean, true);
  reg("blackFlashDamage", Boolean, true);
  reg("zoneAdvantage", Boolean, true);
  reg("domainTracking", Boolean, true);
  reg("domainSureHit", Boolean, true);
  reg("autoExpire", Boolean, true);
  reg("modifierReminders", Boolean, true);
  reg("checkPrereqs", Boolean, true);
  reg("headerButton", Boolean, true, { scope: "client" });
  game.settings.registerMenu(MODULE_ID, "importMenu", {
    name: "JJK5E.Settings.importMenu.Name", label: "JJK5E.Settings.importMenu.Label",
    hint: "JJK5E.Settings.importMenu.Hint", icon: "fas fa-file-import", type: JJKImportMenu, restricted: true
  });

  game.modules.get(MODULE_ID).api = {
    importAll, promptImport, spendCE,
    regainCE: (actor, amount, label) => spendCE(actor, -Math.abs(amount), label || t("CE.Regained")),
    findPool, chooseTechnique, syncTechnique, promptCE, shortRestCE, chooseCEAbility, negativeEmotion,
    applyScaling, openPanel, maximumOutput, setReducedOutput, setSoulAwareness, setLimb, rollLimb,
    summon, dismissSummons, syncResource, missingPrereqs, applyCEEffects, activateGroup, endGroup
  };
});

Hooks.once("ready", async () => {
  if (game.system.id !== "dnd5e") {
    ui.notifications.error(t("Notify.NeedDnd5e"));
    return;
  }
  registerActivityHooks();

  Hooks.on("dnd5e.advancementManagerComplete", async (manager) => {
    const actor = manager?.actor;
    if (!actor?.isOwner) return;
    if (actor.getFlag(MODULE_ID, "technique")) await syncTechnique(actor);
    await applyScaling(actor);
  });
  let pending = new Set();
  Hooks.on("createItem", (item, options, userId) => {
    if (userId !== game.user.id || !item.actor || !item.flags?.jjk5e) return;
    pending.add(item.actor);
    setTimeout(() => { const list = [...pending]; pending = new Set(); list.forEach((a) => applyScaling(a)); }, 250);
  });
  Hooks.on("deleteItem", (item, options, userId) => {
    if (userId === game.user.id && item.actor && (item.flags?.jjk5e?.ceMaxBonus || item.flags?.jjk5e?.cePool)) applyScaling(item.actor);
    refreshPanels(item.actor);
  });
  Hooks.on("updateItem", (item, changes, options, userId) => {
    if (userId === game.user.id && item.flags?.jjk5e?.cePool && !options?.jjk5eSync) syncResource(item.actor);
    refreshPanels(item.actor);
  });
  Hooks.on("updateActor", (actor, changes, options, userId) => {
    onActorUpdate(actor, changes, options, userId);
    refreshPanels(actor);
  });
  for (const h of ["createActiveEffect", "updateActiveEffect", "deleteActiveEffect"]) {
    Hooks.on(h, (effect) => refreshPanels(effect.parent?.documentName === "Actor" ? effect.parent : effect.parent?.actor));
  }
  Hooks.on("deleteActiveEffect", onDeleteEffect);
  Hooks.on("preCreateItem", onPreCreateItem);

  Hooks.on("dnd5e.rollAttackV2", (rolls, data) => onAttackRoll(rolls, data?.subject));
  Hooks.on("dnd5e.rollAttack", (a, b) => {
    if (Array.isArray(a)) return onAttackRoll(a, b?.subject);
    if (b && typeof b === "object" && "isCritical" in b) return onAttackRoll(b, a?.system?.activities?.contents?.[0] ?? a);
  });
  Hooks.on("dnd5e.preRollAttackV2", (config) => onPreRollAttack(config));
  Hooks.on("dnd5e.preRollDamageV2", (config) => onPreRollDamage(config));

  Hooks.on("updateCombat", () => expireEffects());
  Hooks.on("dnd5e.restCompleted", async (actor, result) => {
    if (!actor?.isOwner || result?.longRest) return;
    const n = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.srRegainCE) || 0), 0);
    if (n > 0 && findPool(actor)) await spendCE(actor, -n, t("CE.ShortRestRestore", { n }));
  });
  Hooks.on("updateWorldTime", () => expireEffects());

  Hooks.on("renderActorSheet", (app, html) => addHeaderButton(app, html));
  Hooks.on("renderActorSheetV2", (app, element) => addHeaderButton(app, element));

  game.socket.on(`module.${MODULE_ID}`, (msg) => {
    if (!game.user.isGM || (msg.gm && msg.gm !== game.user.id)) return;
    if (msg.action === "summon") gmSummon(msg.payload);
    if (msg.action === "dismiss") gmDismiss(msg.payload);
  });

  if (game.user.character) syncResource(game.user.character);
  if (game.user.isGM && setting("importedVersion") !== DATA_VERSION) await promptImport(false);
});

/* -------------------------------------------- */
/*  1.7: Class-integrated techniques, point buy, */
/*  JJK feats on ASI, domain sure-hit, animations */
/* -------------------------------------------- */

/* ---- Innate technique chosen through the class advancement ---- */

async function onTechniqueRootCreated(item) {
  const name = item.flags?.jjk5e?.techniqueRoot;
  const actor = item.actor;
  if (!name || !actor?.isOwner) return;
  if (actor.getFlag(MODULE_ID, "technique") !== name) await actor.setFlag(MODULE_ID, "technique", name);
}

async function onTechniqueRootDeleted(item) {
  const name = item.flags?.jjk5e?.techniqueRoot;
  const actor = item.actor;
  if (!name || !actor?.isOwner) return;
  if (actor.getFlag(MODULE_ID, "technique") === name) await actor.unsetFlag(MODULE_ID, "technique");
}

/* ---- Point buy ---- */

const ABILITY_KEYS = ["str", "dex", "con", "int", "wis", "cha"];

function pointBuyConfig() {
  return {
    budget: Number(setting("pointBuyBudget")) || 27,
    min: Number(setting("pointBuyMin")) || 10,
    max: Number(setting("pointBuyMax")) || 18,
    double: Number(setting("pointBuyDoubleFrom")) || 14
  };
}

const DEFAULT_POINT_COSTS = "10:0, 11:1, 12:2, 13:3, 14:5, 15:7, 16:10, 17:13, 18:17";

/** Point cost table: "score:cost" pairs (total cost of buying that score). */
function pointCostTable() {
  const table = {};
  for (const pair of String(setting("pointBuyCosts") || DEFAULT_POINT_COSTS).split(/[,;\n]+/)) {
    const [k, v] = pair.split(":").map((x) => Number(x.trim()));
    if (Number.isFinite(k) && Number.isFinite(v)) table[k] = v;
  }
  return table;
}

/** Total cost of a score, from the cost table (falls back to 1 point per step, 2 from the "double" score). */
function pointCost(score, cfg = pointBuyConfig()) {
  const table = pointCostTable();
  if (score in table) return table[score];
  let cost = 0;
  for (let s = cfg.min + 1; s <= score; s++) cost += s >= cfg.double ? 2 : 1;
  return cost;
}

function pointBuyContent(values, cfg) {
  const rows = ABILITY_KEYS.map((k) => {
    const label = CONFIG.DND5E?.abilities?.[k]?.label ?? k.toUpperCase();
    return `<tr><td><strong>${esc(game.i18n.localize(label))}</strong></td>
      <td><input type="number" name="${k}" value="${values[k]}" min="${cfg.min}" max="${cfg.max}" step="1" style="width:5em"></td>
      <td class="jjk-pb-cost" data-ability="${k}">${pointCost(values[k], cfg)}</td></tr>`;
  }).join("");
  const spent = ABILITY_KEYS.reduce((n, k) => n + pointCost(values[k], cfg), 0);
  const costs = Object.entries(pointCostTable()).filter(([k]) => Number(k) >= cfg.min && Number(k) <= cfg.max)
    .map(([k, v]) => `<span class="jjk-pb-chip">${k}: <strong>${v}</strong></span>`).join("");
  return `<p>${t("PointBuy.Hint", cfg)}</p><div class="jjk-pb-costs">${costs}</div>
    <table class="jjk-pb"><thead><tr><th>${t("PointBuy.Ability")}</th><th>${t("PointBuy.Score")}</th><th>${t("PointBuy.Cost")}</th></tr></thead>
    <tbody>${rows}</tbody></table>
    <p class="jjk-pb-total">${t("PointBuy.Remaining")}: <strong data-remaining>${cfg.budget - spent}</strong> / ${cfg.budget}</p>
    <p class="hint"><em>${t("PointBuy.Order")}</em></p>`;
}

function bindPointBuy(root, cfg) {
  if (!root) return;
  const update = () => {
    let spent = 0;
    for (const k of ABILITY_KEYS) {
      const input = root.querySelector(`input[name="${k}"]`);
      const v = clamp(Math.round(Number(input?.value) || cfg.min), cfg.min, cfg.max);
      const c = pointCost(v, cfg);
      spent += c;
      const cell = root.querySelector(`.jjk-pb-cost[data-ability="${k}"]`);
      if (cell) cell.textContent = c;
    }
    const rem = root.querySelector("[data-remaining]");
    if (rem) {
      rem.textContent = cfg.budget - spent;
      rem.style.color = spent > cfg.budget ? "#c00" : "";
    }
  };
  root.querySelectorAll("input[type=number]").forEach((i) => i.addEventListener("input", update));
  update();
}

async function pointBuy(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  if (!actor.isOwner) return ui.notifications.warn(t("Notify.NotOwner"));
  const cfg = pointBuyConfig();
  let values = Object.fromEntries(ABILITY_KEYS.map((k) =>
    [k, clamp(Number(actor.system.abilities?.[k]?.value) || cfg.min, cfg.min, cfg.max)]));
  const DialogV2 = foundry.applications.api.DialogV2;
  for (;;) {
    const result = await DialogV2.wait({
      window: { title: t("PointBuy.Title"), icon: "fas fa-dice-d20" },
      content: pointBuyContent(values, cfg),
      rejectClose: false,
      render: (event, dialog) => bindPointBuy((dialog?.element ?? dialog) instanceof HTMLElement
        ? (dialog.element ?? dialog) : event?.target?.element, cfg),
      buttons: [
        { action: "apply", label: t("PointBuy.Apply"), icon: "fas fa-check", default: true,
          callback: (event, button) => Object.fromEntries(ABILITY_KEYS.map((k) =>
            [k, clamp(Math.round(Number(button.form.elements[k]?.value) || cfg.min), cfg.min, cfg.max)])) },
        { action: "cancel", label: t("Common.Cancel"), icon: "fas fa-times" }
      ]
    });
    if (!result || result === "cancel" || typeof result !== "object") return;
    values = result;
    const spent = ABILITY_KEYS.reduce((n, k) => n + pointCost(values[k], cfg), 0);
    if (spent > cfg.budget) {
      ui.notifications.warn(t("PointBuy.Over", { spent, budget: cfg.budget }));
      continue;
    }
    await actor.update(Object.fromEntries(ABILITY_KEYS.map((k) => [`system.abilities.${k}.value`, values[k]])));
    ui.notifications.info(t("PointBuy.Done", { name: actor.name, left: cfg.budget - spent }));
    return values;
  }
}

/* ---- JJK feats inside the Ability Score Improvement step ---- */

let featDocsCache = null;
async function jjkFeatDocs() {
  const pack = game.packs.get("world.jjk5e-feats");
  if (!pack) return [];
  featDocsCache ??= pack.getDocuments();
  return featDocsCache;
}

async function injectASIFeats(app, element) {
  if (!setting("asiFeatPicker")) return;
  const adv = app?.advancement;
  if (!adv || adv.type !== "AbilityScoreImprovement") return;
  if (!(adv.item?.type === "class" || adv.item?.type === "subclass")) return;
  if (Object.values(adv.configuration?.fixed ?? {}).some((v) => v)) return;
  const root = element instanceof HTMLElement ? element : (element?.[0] ?? app.element);
  if (!root || root.querySelector(".jjk5e-asi")) return;
  const actor = adv.actor;
  const docs = await jjkFeatDocs();
  if (!docs.length) return;
  const owned = new Set(actor.items.map((i) => normName(i.name)));
  const eligible = docs.filter((d) => d.system?.type?.value === "feat"
    && (!owned.has(normName(d.name)) || d.system?.prerequisites?.repeatable)
    && !missingPrereqs(actor, d).length)
    .sort((a, b) => a.name.localeCompare(b.name));
  const box = document.createElement("fieldset");
  box.className = "jjk5e-asi";
  box.innerHTML = `<legend>${t("ASI.Legend")}</legend>
    <p class="hint">${t("ASI.Hint", { n: eligible.length })}</p>
    <div class="form-group"><select name="jjk5e-feat" style="flex:1">
      <option value="">—</option>
      ${Object.entries(Object.groupBy(eligible, (d) => d.system?.type?.subtype || "general"))
        .sort(([a], [b]) => featCategoryLabel(a).localeCompare(featCategoryLabel(b)))
        .map(([sub, list]) => `<optgroup label="${esc(featCategoryLabel(sub))}">`
          + list.map((d) => `<option value="${d.uuid}">${esc(d.name)}</option>`).join("") + "</optgroup>").join("")}
    </select>
    <button type="button" data-jjk-take style="flex:0 0 auto"><i class="fas fa-plus"></i> ${t("ASI.Take")}</button></div>`;
  box.querySelector("[data-jjk-take]").addEventListener("click", async (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    const uuid = box.querySelector("select")?.value;
    if (!uuid) return;
    await adv.apply(app.level, { retainedItems: app.retainedData?.retainedItems, type: "feat", uuid });
    app.render();
  });
  (root.querySelector("form") ?? root.querySelector(".window-content") ?? root).append(box);
}

function featCategoryLabel(sub) {
  const label = CONFIG.DND5E?.featureTypes?.feat?.subtypes?.[sub];
  return String(game.i18n.localize(typeof label === "string" ? label : (label?.label ?? sub)) ?? sub);
}

/* ---- Domain sure-hit ---- */

function applySureHit(actor, config) {
  if (!setting("domainSureHit") || !domainOpen(actor) || game.modules.get("midi-qol")?.active) return;
  const item = config?.subject?.item;
  if (!item?.flags?.jjk5e?.technique) return;
  const roll = config?.rolls?.[0];
  if (!roll) return;
  roll.options ??= {};
  roll.options.criticalFailure = -1;
  addPart(config, `99[${t("Domain.SureHitShort")}]`);
}

/* ---- Animations (Sequencer + JB2A, optional) ---- */

/** Animation sets by theme. proj = projectile (stretch), melee, impact (on target), area (centered), cone, line, buff. */
const ANIM_THEMES = {
  ce: { proj: "jb2a.energy_strands.range.standard.purple.01", melee: "jb2a.unarmed_strike.magical.01.blue",
    impact: "jb2a.impact.001.blue", area: "jb2a.shatter.blue", cone: "jb2a.energy_strands.range.standard.purple.01",
    buff: "jb2a.energy_strands.complete.blue.01", line: "jb2a.energy_beam.normal.blue.01" },
  physical: { melee: "jb2a.unarmed_strike.physical.01.blue", impact: "jb2a.impact.003.blue", area: "jb2a.ground_cracks.orange.01",
    proj: "jb2a.throwable.launch.cannon_ball.01.black", buff: "jb2a.extras.tmfx.border.circle.outpulse.01.normal" },
  fist: { melee: "jb2a.flurry_of_blows.magical.01.blue", impact: "jb2a.impact.004.blue", area: "jb2a.ground_cracks.orange.01",
    proj: "jb2a.energy_strands.range.standard.purple.01", buff: "jb2a.static_electricity.01.blue" },
  blade: { melee: "jb2a.sword.melee.01.white", impact: "jb2a.melee_generic.slash.01.orange",
    proj: "jb2a.melee_generic.slash.01.orange", area: "jb2a.melee_generic.whirlwind.01.orange", targetOnly: true },
  fire: { proj: "jb2a.fire_bolt.orange", impact: "jb2a.explosion.01.orange", area: "jb2a.fireball.explosion.orange",
    cone: "jb2a.burning_hands.01.orange", line: "jb2a.fire_jet.orange", buff: "jb2a.shield_themed.above.fire.01.orange",
    melee: "jb2a.flames.01.orange" },
  cold: { proj: "jb2a.spell_projectile.ice_shard.blue", impact: "jb2a.impact_themed.ice_shard.blue",
    area: "jb2a.ice_spikes.radial.burst.white", cone: "jb2a.cone_of_cold.blue", line: "jb2a.ray_of_frost.blue",
    buff: "jb2a.shield_themed.above.ice.01.blue" },
  lightning: { proj: "jb2a.chain_lightning.primary.blue", impact: "jb2a.static_electricity.01.blue",
    area: "jb2a.thunderwave.center.blue", line: "jb2a.lightning_bolt.wide.blue", cone: "jb2a.lightning_bolt.wide.blue",
    buff: "jb2a.static_electricity.02.blue", melee: "jb2a.static_electricity.03.blue" },
  water: { proj: "jb2a.energy_beam.normal.blue.01", impact: "jb2a.liquid.splash.blue", area: "jb2a.water_splash.circle.01.blue",
    cone: "jb2a.water_splash.cone.01.blue", buff: "jb2a.liquid.blob.blue" },
  earth: { proj: "jb2a.boulder.toss.02.01.stone.brown", impact: "jb2a.ground_cracks.01.orange", area: "jb2a.ground_cracks.orange.02",
    buff: "jb2a.shield_themed.above.molten_earth.01.orange", melee: "jb2a.impact.ground_crack.orange.01" },
  blood: { proj: "jb2a.bullet.01.orange", impact: "jb2a.claws.200px.red", area: "jb2a.bats.complete.01.red",
    buff: "jb2a.bats.loop.01.red", melee: "jb2a.claws.200px.red" },
  shadow: { proj: "jb2a.eldritch_blast.purple", impact: "jb2a.black_tentacles.dark_purple", area: "jb2a.darkness.black",
    buff: "jb2a.shield_themed.above.eldritch_web.01.dark_purple", summon: "jb2a.smoke.puff.ring.01.white",
    melee: "jb2a.claws.200px.red" },
  void: { proj: "jb2a.overcharged_sphere.01.01.dark_purple", impact: "jb2a.sphere_of_annihilation.200px.purple",
    area: "jb2a.sphere_of_annihilation.600px.purple", line: "jb2a.disintegrate.green", buff: "jb2a.energy_field.01.blue" },
  nature: { proj: "jb2a.spell_projectile.ice_shard.blue", impact: "jb2a.entangle.green", area: "jb2a.vine.complete.nature.group.01.green",
    buff: "jb2a.swirling_leaves" },
  wind: { proj: "jb2a.gust_of_wind.veryfast", impact: "jb2a.side_impact.part.smoke.blue.01", area: "jb2a.whirlwind",
    cone: "jb2a.gust_of_wind.default", line: "jb2a.wind_stream.white", buff: "jb2a.wind_lines.01.01.white" },
  sound: { proj: "jb2a.soundwave.02.blue", impact: "jb2a.soundwave.01.blue", area: "jb2a.thunderwave.center.blue",
    cone: "jb2a.soundwave.02.blue", buff: "jb2a.music_notations.beamed_quavers.blue" },
  star: { proj: "jb2a.celestial_bodies.asteroid.disk.iron.red.01", impact: "jb2a.twinkling_stars.points05.white",
    area: "jb2a.particle_burst.01.star.bluepurple", buff: "jb2a.twinkling_stars.points04.white" },
  gun: { proj: "jb2a.bullet.01.orange", impact: "jb2a.impact.005.orange", area: "jb2a.explosion.01.orange",
    line: "jb2a.lasershot.blue" },
  mind: { proj: "jb2a.magic_missile.purple", impact: "jb2a.dizzy_stars", area: "jb2a.sleep.cloud.01.pink",
    buff: "jb2a.eyes.01.dark_green.few" },
  barrier: { buff: "jb2a.shield.01.complete.01.blue", area: "jb2a.energy_wall", impact: "jb2a.ward.rune.yellow.01" },
  heal: { impact: "jb2a.healing_generic.200px.green", area: "jb2a.cure_wounds.400px.blue", buff: "jb2a.healing_generic.400px.green" },
  curse: { proj: "jb2a.eldritch_blast.purple", impact: "jb2a.toll_the_dead.green.skull_smoke", area: "jb2a.toll_the_dead.green.shockwave" }
};

/** Keywords (technique name, item name, description) that pick the theme. First match wins. */
const ANIM_RULES = [
  ["heal", /\b(reverse cursed technique|rct|heal(?:s|ing)?|regenerat|restor)/i],
  ["barrier", /\b(barrier|curtain|veil|shield|ward|wall|simple domain|hollow wicker)/i],
  ["void", /\b(limitless|infinity|hollow purple|purple|blue\b|red\b|void|black hole|gravity|antigravity|sphere)/i],
  ["shadow", /\b(ten shadows|shadow|darkness|dark|abyss|shikigami|chimera)/i],
  ["fire", /\b(fire|flame|blaze|blazing|burn|ember|magma|volcan|disaster flames|heat|explosi)/i],
  ["cold", /\b(ice|frost|cold|freez|snow|glacier)/i],
  ["lightning", /\b(lightning|electr|thunder|spark|amber|voltage|plasma)/i],
  ["water", /\b(water|tide|wave|flood|ocean|sea\b|disaster tides|rain)/i],
  ["earth", /\b(earth|rock|stone|boulder|construction|quake|ground)/i],
  ["blood", /\b(blood|crimson|piercing blood|flowing red)/i],
  ["nature", /\b(plant|verdure|vine|root|flower|tree|wood)/i],
  ["wind", /\b(wind|storm|sky|air|gust|tornado|disaster storms)/i],
  ["sound", /\b(sound|voice|song|speech|music|rockstar|melody|scream|roar)/i],
  ["star", /\b(star|moon|celestial|cosmic|meteor|starlight|comet)/i],
  ["gun", /\b(gun|bullet|cannon|missile|shot|fever|pachinko)/i],
  ["mind", /\b(mind|illusion|mirage|fate|laplace|psychic|madness|faceless|charm|paraly)/i],
  ["blade", /\b(sword|blade|cleave|dismantle|slash|cut|shrine|katana|sever|new shadow style)/i],
  ["fist", /\b(fist|punch|divergent|black flash|strike|kick|martial|fa jin|ratio)/i],
  ["curse", /\b(curse|cursed spirit|rot|vermin|disaster|spirit)/i]
];
const DAMAGE_THEME = { fire: "fire", cold: "cold", lightning: "lightning", thunder: "sound", psychic: "mind",
  necrotic: "curse", radiant: "star", force: "void", acid: "nature", poison: "nature", healing: "heal" };

const ANIM = { blackFlash: "jb2a.impact.005.orange", blackFlash2: "jb2a.static_electricity.03.blue",
  domain: "jb2a.darkness.black", domainAura: "jb2a.template_circle.aura.01.loop.large.bluepurple",
  summon: "jb2a.smoke.puff.ring.01.white", teleport: "jb2a.misty_step.01.blue", weapon: "jb2a.melee_generic.slash.01.orange" };

function animOn() {
  return setting("animations") && game.modules.get("sequencer")?.active && typeof Sequence !== "undefined";
}

function animOverrides() {
  try { return JSON.parse(setting("animOverrides") || "{}"); } catch (err) { return {}; }
}

/** Return a usable Sequencer path, walking down to a parent key for range-based entries. */
function animPath(file) {
  if (!file) return null;
  if (!file.startsWith("jb2a.") || !globalThis.Sequencer?.Database?.entryExists) return file;
  return Sequencer.Database.entryExists(file) ? file : null;
}

function itemTheme(item, activity) {
  const custom = item?.flags?.jjk5e?.animTheme;
  if (custom && ANIM_THEMES[custom]) return custom;
  const tech = item?.flags?.jjk5e?.technique ?? "";
  const text = `${tech} ${item?.name ?? ""}`;
  for (const [theme, re] of ANIM_RULES) if (re.test(text)) return theme;
  const dmg = damageKind(activity);
  if (dmg && DAMAGE_THEME[dmg]) return DAMAGE_THEME[dmg];
  const desc = String(item?.system?.description?.value ?? "").slice(0, 600);
  for (const [theme, re] of ANIM_RULES) if (re.test(desc)) return theme;
  return item?.type === "weapon" ? "physical" : "ce";
}

function themeFile(theme, slot, item) {
  const o = animOverrides();
  const per = item?.flags?.jjk5e?.anim?.[slot];
  const chain = [per, o[`${theme}.${slot}`], o[slot], ANIM_THEMES[theme]?.[slot],
    ANIM_THEMES.ce[slot]].filter(Boolean);
  for (const f of chain) { const p = animPath(f); if (p) return p; }
  return null;
}

function aaHandles(item) {
  return !!(game.modules.get("autoanimations")?.active && item?.flags?.autoanimations?.isEnabled);
}

function tokenOf(actor) {
  return actor?.getActiveTokens?.()?.[0] ?? null;
}

function damageKind(activity) {
  const types = [...(activity?.damage?.parts ?? [])].flatMap((p) => [...(p.types ?? [])]);
  if (!types.length && activity?.type === "heal") return "healing";
  return types[0] ?? null;
}

function playAt(file, target, { scale = 1, persist = false, name, gridSize = null, below = false } = {}) {
  if (!file || !target) return;
  const seq = new Sequence().effect().file(file).atLocation(target);
  if (gridSize) seq.size(gridSize, { gridUnits: true });
  else seq.scaleToObject(scale);
  if (below) seq.belowTokens();
  if (persist) seq.attachTo(target).persist().belowTokens().opacity(0.55).name(name);
  seq.play();
}

function playBetween(file, source, target, missed = false) {
  if (!file || !source || !target) return;
  new Sequence().effect().file(file).atLocation(source).stretchTo(target).missed(missed).play();
}

/** Play the animation for an attack against one target (hit or miss already known). */
function animateHit(item, activity, source, target, missed) {
  const theme = itemTheme(item, activity);
  const melee = (activity?.attack?.type?.value ?? "melee") === "melee";
  if (item.type === "weapon" && !item.flags?.jjk5e?.technique) {
    if (melee) return playBetween(animPath(ANIM.weapon), source, target, missed);
    return playBetween(themeFile("gun", "proj", item), source, target, missed);
  }
  if (melee) {
    const file = themeFile(theme, "melee", item) ?? themeFile(theme, "impact", item);
    if (!missed) playAt(file, target, { scale: 1.6 });
    return;
  }
  if (ANIM_THEMES[theme]?.targetOnly) { if (!missed) playAt(themeFile(theme, "impact", item), target, { scale: 1.6 }); return; }
  playBetween(themeFile(theme, "proj", item), source, target, missed);
  if (!missed) setTimeout(() => playAt(themeFile(theme, "impact", item), target, { scale: 1.3 }), 650);
}

function animateAttack(rolls, subject) {
  if (!animOn() || midiActive()) return;
  const activity = subject?.activity ?? subject;
  const item = activity?.item;
  if (!item?.flags?.jjk5e || aaHandles(item)) return;
  const source = tokenOf(item.actor);
  const roll = Array.isArray(rolls) ? rolls[0] : rolls;
  if (!source) return;
  for (const target of game.user.targets) {
    const ac = Number(target.actor?.system?.attributes?.ac?.value);
    const missed = !!roll && !roll.isCritical && Number.isFinite(ac) && roll.total < ac;
    animateHit(item, activity, source, target, missed);
  }
}

function animateActivity(activity, targets = null) {
  if (!animOn() || !activity || activity.type === "attack") return;
  targets ??= [...(game.user.targets ?? [])];
  const item = activity.item;
  if (!item?.flags?.jjk5e || aaHandles(item)) return;
  const source = tokenOf(item.actor);
  if (!source) return;
  const theme = itemTheme(item, activity);
  const tmpl = activity.target?.template ?? {};
  const name = item.name.toLowerCase();
  if (item.flags.jjk5e.domainActivity === activity.id || name.startsWith("domain expansion")) {
    playAt(animPath(ANIM.domain), source, { scale: 6 });
    playAt(themeFile(theme, "area", item), source, { scale: 8, below: true });
    playAt(animPath(ANIM.domainAura), source, { scale: 10, persist: true, name: `jjk5e-domain-${item.actor.id}` });
    return;
  }
  if (activity.type === "summon") return playAt(themeFile("shadow", "summon", item) ?? animPath(ANIM.summon), source, { scale: 2.5 });
  if (/teleport|blink|swap|boogie/.test(name)) return playAt(animPath(ANIM.teleport), source, { scale: 1.5 });
  if (activity.type === "heal") {
    for (const tk of targets.length ? targets : [source]) playAt(themeFile("heal", "impact", item), tk, { scale: 1.5 });
    return;
  }
  if (activity.type === "save" || activity.type === "damage") {
    const size = Number(tmpl.size) || 0;
    const dist = canvas?.scene?.grid?.distance || 5;
    if (tmpl.type === "cone" || tmpl.type === "line") {
      const slot = tmpl.type === "cone" ? "cone" : "line";
      const tgt = targets[0];
      if (tgt) playBetween(themeFile(theme, slot, item) ?? themeFile(theme, "proj", item), source, tgt);
    } else if (tmpl.type) {
      const at = activity.range?.units === "self" || !targets.length ? source : targets[0];
      playAt(themeFile(theme, "area", item), at, size ? { gridSize: (size * 2) / dist } : { scale: 3 });
    } else if (activity.range?.units && activity.range.units !== "self" && activity.range.units !== "touch") {
      for (const tk of targets) playBetween(themeFile(theme, "proj", item), source, tk);
    }
    for (const tk of targets) setTimeout(() => playAt(themeFile(theme, "impact", item), tk, { scale: 1.4 }), 600);
    return;
  }
  if (activity.type === "utility" || activity.type === "enchant") {
    if (targets.length && activity.range?.units !== "self") {
      for (const tk of targets) playAt(themeFile(theme, "impact", item), tk, { scale: 1.4 });
    } else playAt(themeFile(theme, "buff", item), source, { scale: 1.8 });
  }
}

function endDomainAnimation(actor) {
  if (globalThis.Sequencer?.EffectManager && actor) Sequencer.EffectManager.endEffects({ name: `jjk5e-domain-${actor.id}` });
}

function animateBlackFlash(actor) {
  if (!animOn()) return;
  const source = tokenOf(actor);
  const target = [...game.user.targets][0] ?? source;
  playAt(animPath(ANIM.blackFlash), target, { scale: 2.5 });
  playAt(animPath(ANIM.blackFlash2), target, { scale: 2 });
}

/* ---- Midi-QOL integration (optional) ---- */

function midiActive() {
  return !!game.modules.get("midi-qol")?.active;
}

function registerMidiHooks() {
  if (!midiActive()) return;
  // Domain sure-hit: every target of an innate-technique attack is hit.
  Hooks.on("midi-qol.AttackRollComplete", (workflow) => {
    try {
      const actor = workflow?.actor;
      const item = workflow?.item;
      if (!setting("domainSureHit") || !domainOpen(actor) || !item?.flags?.jjk5e?.technique) return;
      workflow.hitTargets = new Set(workflow.targets);
    } catch (err) { console.error(`${MODULE_ID} | midi sure-hit`, err); }
  });
  // Domain sure-hit: targets automatically fail the saving throws of your innate technique.
  Hooks.on("midi-qol.postCheckSaves", (workflow) => {
    try {
      const item = workflow?.item;
      if (!setting("domainSureHit") || !domainOpen(workflow?.actor) || !item?.flags?.jjk5e?.technique) return;
      const all = new Set([...(workflow.saves ?? []), ...(workflow.failedSaves ?? [])]);
      workflow.failedSaves = all;
      workflow.saves = new Set();
    } catch (err) { console.error(`${MODULE_ID} | midi sure-hit saves`, err); }
  });
  // Animations with Midi's real hit list.
  Hooks.on("midi-qol.RollComplete", (workflow) => {
    try {
      if (!animOn()) return;
      const item = workflow?.item;
      const activity = workflow?.activity;
      if (!item?.flags?.jjk5e || aaHandles(item) || activity?.type !== "attack") return;
      const source = workflow.token ?? tokenOf(item.actor);
      for (const target of workflow.targets ?? []) animateHit(item, activity, source, target, !workflow.hitTargets?.has(target));
    } catch (err) { console.error(`${MODULE_ID} | midi animation`, err); }
  });
}

/* ---- Level up from the XP bar ---- */

async function levelUp(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  if (!actor.isOwner) return ui.notifications.warn(t("Notify.NotOwner"));
  const classes = actor.items.filter((i) => i.type === "class");
  if (!classes.length) return ui.notifications.warn(t("LevelUp.NoClass"));
  if ((Number(actor.system.details?.level) || 0) >= 20) return ui.notifications.warn(t("LevelUp.Max"));
  let cls = classes[0];
  if (classes.length > 1) {
    const options = classes.map((c) => `<option value="${c.id}">${esc(c.name)} (${c.system.levels})</option>`).join("");
    const id = await promptField(t("LevelUp.Title"), `<p>${t("LevelUp.Which")}</p><select name="cls" style="width:100%">${options}</select>`, "cls");
    if (!id) return;
    cls = actor.items.get(id);
  }
  const AM = globalThis.dnd5e?.applications?.advancement?.AdvancementManager;
  if (AM && !game.settings.get("dnd5e", "disableAdvancements")) {
    const manager = AM.forLevelChange(actor, cls.id, 1);
    if (manager.steps.length) return manager.render({ force: true });
  }
  return cls.update({ "system.levels": cls.system.levels + 1 });
}

function addLevelUpButton(app, element) {
  const actor = app?.actor ?? app?.document;
  if (!setting("levelUpButton") || actor?.type !== "character" || !actor.isOwner) return;
  const root = element instanceof HTMLElement ? element : (element?.[0] ?? app.element);
  const xp = actor.system.details?.xp;
  const lvl = Number(actor.system.details?.level) || 0;
  root?.querySelector?.(".jjk5e-levelup")?.remove();
  if (!xp || !(Number(xp.max) > 0) || Number(xp.value) < Number(xp.max) || lvl >= 20 || lvl < 1) return;
  const bar = root?.querySelector?.(".xp-bar, .experience, .xp");
  if (!bar) return;
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "jjk5e-levelup";
  btn.innerHTML = `<i class="fas fa-angles-up"></i> ${t("LevelUp.Button")}`;
  btn.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); levelUp(actor); });
  bar.after(btn);
}

/* ---- Summons for players without token-creation rights ---- */

async function summonFallback(activity) {
  if (activity?.type !== "summon" || activity.canSummon) return;
  const info = activity.item?.flags?.jjk5e?.summons?.[activity.id];
  const profile = activity.profiles?.[0];
  const name = info?.name ?? profile?.name;
  if (!name) return;
  const actor = activity.actor;
  const rollData = activity.getRollData?.() ?? actor.getRollData();
  const evalF = async (f) => (f ? (await new Roll(String(f), rollData).evaluate()).total : 0);
  const src = game.actors.find((a) => a.name === name);
  const base = src?.system?.attributes ?? {};
  const stats = {
    hp: (Number(base.hp?.max) || 0) + (await evalF(activity.bonuses?.hp)),
    ac: (Number(base.ac?.flat ?? base.ac?.value) || 10) + (await evalF(activity.bonuses?.ac))
  };
  return viaGM("summon", { actorUuid: actor.uuid, name, count: Number(info?.count ?? profile?.count) || 1,
    userId: game.user.id, sceneId: canvas.scene?.id, stats });
}

Hooks.once("init", () => {
  const reg = (key, type, def, extra = {}) => game.settings.register(MODULE_ID, key, {
    name: `JJK5E.Settings.${key}.Name`, hint: `JJK5E.Settings.${key}.Hint`,
    scope: "world", config: true, type, default: def, ...extra
  });
  // Innate technique abilities are spells cast with the "Innate Technique" method (no slots; they spend CE).
  if (CONFIG.DND5E?.spellcasting && !CONFIG.DND5E.spellcasting.technique) {
    CONFIG.DND5E.spellcasting.technique = { label: "JJK5E.Spell.Method", order: -25 };
  }
  if (CONFIG.DND5E?.spellSchools) {
    CONFIG.DND5E.spellSchools.jjk = { label: "JJK5E.Spell.School", icon: `modules/${MODULE_ID}/icons/ce.svg`,
      fullKey: "cursedtechnique" };
  }
  const featSubs = CONFIG.DND5E?.featureTypes?.feat?.subtypes;
  if (featSubs) {
    for (const k of ["Physical", "CursedEnergy", "Barrier", "RCT", "Skill", "Technique", "Pact", "Boon", "Trait", "CursedTechnique"]) {
      featSubs[`jjk${k}`] = `JJK5E.FeatType.${k}`;
    }
  }
  reg("pointBuyBudget", Number, 27);
  reg("pointBuyMin", Number, 10);
  reg("pointBuyMax", Number, 18);
  reg("pointBuyDoubleFrom", Number, 14);
  reg("pointBuyCosts", String, "10:0, 11:1, 12:2, 13:3, 14:5, 15:7, 16:10, 17:13, 18:17");
  reg("asiFeatPicker", Boolean, true);
  reg("animations", Boolean, true, { scope: "client" });
  reg("animOverrides", String, "");
  reg("levelUpButton", Boolean, true, { scope: "client" });
  reg("enableSummoning", Boolean, true);
  Object.assign(game.modules.get(MODULE_ID).api ?? {}, { pointBuy, pointCost, ANIM, ANIM_THEMES, itemTheme, levelUp });
});

Hooks.once("ready", () => {
  if (game.system.id !== "dnd5e") return;
  Hooks.on("createItem", (item, options, userId) => {
    if (userId === game.user.id && item.flags?.jjk5e?.techniqueRoot) onTechniqueRootCreated(item);
  });
  Hooks.on("deleteItem", (item, options, userId) => {
    if (userId === game.user.id && item.flags?.jjk5e?.techniqueRoot) onTechniqueRootDeleted(item);
  });
  Hooks.on("renderAbilityScoreImprovementFlow", (app, element) => { injectASIFeats(app, element); });
  Hooks.on("dnd5e.rollAttackV2", (rolls, data) => animateAttack(rolls, data?.subject));
  Hooks.on("dnd5e.postUseActivity", (activity) => { animateActivity(activity); summonFallback(activity); });
  Hooks.on("renderCharacterActorSheet", (app, element) => addLevelUpButton(app, element));
  Hooks.on("renderActorSheetV2", (app, element) => addLevelUpButton(app, element));
  Hooks.on("updateActor", (actor, changes) => {
    if (foundry.utils.hasProperty(changes, "system.details.xp")) for (const app of foundry.applications.instances?.values?.() ?? []) {
      if (app.document === actor && app.rendered) addLevelUpButton(app, app.element);
    }
  });
  registerMidiHooks();
  if (game.user.isGM && setting("enableSummoning") && game.settings.settings?.has?.("dnd5e.allowSummoning")
    && !game.settings.get("dnd5e", "allowSummoning")) game.settings.set("dnd5e", "allowSummoning", true);
  Hooks.on("deleteActiveEffect", (effect) => {
    if (effect.flags?.jjk5e?.kind === "domain" || effect.flags?.jjk5e?.domainOpen) endDomainAnimation(effect.parent);
  });
  Hooks.on("updateActor", (actor, changes) => {
    if (foundry.utils.getProperty(changes, `flags.${MODULE_ID}.pendingBlackFlash`) === true) animateBlackFlash(actor);
  });
  Hooks.on("updateItem", () => { featDocsCache = null; });
});

/* ---- Error reporter: shows JJK 5e errors as notifications so they can be reported without the console ---- */

function reportJJKError(err) {
  const stack = String(err?.stack ?? "");
  if (!stack.includes(`modules/${MODULE_ID}/`)) return;
  console.error(`${MODULE_ID} |`, err);
  ui.notifications?.error(`JJK 5e: ${err?.message ?? err}`, { permanent: true });
}
globalThis.window?.addEventListener?.("error", (ev) => reportJJKError(ev.error));
globalThis.window?.addEventListener?.("unhandledrejection", (ev) => reportJJKError(ev.reason));

/* ---- Compact JJK menu (one button in the Token scene controls) ---- */

const MENU_ACTIONS = [
  ["panel", "fa-solid fa-yin-yang", "SceneTools.Panel", (a) => openPanel(a)],
  ["spend", "fa-solid fa-bolt", "SceneTools.Spend", (a) => promptCE("spend", a)],
  ["regain", "fa-solid fa-battery-full", "SceneTools.Regain", (a) => promptCE("regain", a)],
  ["technique", "fa-solid fa-hand-sparkles", "SceneTools.Technique", (a) => chooseTechnique(a)],
  ["ceAbility", "fa-solid fa-brain", "SceneTools.CEAbility", (a) => chooseCEAbility(a)],
  ["negEmotion", "fa-solid fa-face-angry", "SceneTools.NegEmotion", (a) => negativeEmotion(a)],
  ["shortRest", "fa-solid fa-bed", "SceneTools.ShortRest", (a) => shortRestCE(a)],
  ["maxOutput", "fa-solid fa-burst", "SceneTools.MaxOutput", (a) => maximumOutput(a)],
  ["limb", "fa-solid fa-bone", "SceneTools.Limb", (a) => rollLimb(a)],
  ["pointBuy", "fa-solid fa-dice-d20", "SceneTools.PointBuy", (a) => pointBuy(a)],
  ["levelUp", "fa-solid fa-angles-up", "SceneTools.LevelUp", (a) => levelUp(a)],
  ["import", "fa-solid fa-file-import", "SceneTools.Import", () => promptImport(true), true]
];

/** Characters the user can act for: controlled tokens first, then their character, then owned characters. */
function menuActors() {
  const list = [];
  const add = (a) => { if (a?.isOwner && !list.includes(a)) list.push(a); };
  canvas?.tokens?.controlled?.forEach((tk) => add(tk.actor));
  add(game.user.character);
  game.actors?.filter((a) => a.type === "character").forEach(add);
  return list;
}

let JJKMenuApp = null;
function makeMenuClass() {
  const Base = foundry.applications.api.ApplicationV2;
  return class JJKMenu extends Base {
    static DEFAULT_OPTIONS = {
      id: "jjk5e-menu",
      classes: ["jjk5e-menu"],
      window: { title: "JJK 5e", icon: "fas fa-yin-yang", minimizable: true },
      position: { width: 250, height: "auto", left: 110, top: 80 },
      actions: { run: JJKMenu.#run }
    };

    async _renderHTML() {
      const actors = menuActors();
      const keep = this.actorId && actors.some((a) => a.id === this.actorId) ? this.actorId : actors[0]?.id;
      this.actorId = keep;
      const opts = actors.map((a) => `<option value="${a.id}" ${a.id === keep ? "selected" : ""}>${esc(a.name)}</option>`).join("");
      const btns = MENU_ACTIONS.filter(([, , , , gm]) => !gm || game.user.isGM)
        .map(([key, icon, label]) => `<button type="button" data-action="run" data-key="${key}" title="${esc(t(label))}">`
          + `<i class="${icon}"></i><span>${esc(t(label).replace(/^JJK:\s*/, ""))}</span></button>`).join("");
      return `<div class="jjk-menu-actor">${actors.length
        ? `<select name="actor">${opts}</select>` : `<em>${t("Notify.NoActor")}</em>`}</div>
        <div class="jjk-menu-grid">${btns}</div>`;
    }

    _replaceHTML(result, content) {
      content.innerHTML = result;
      content.querySelector("select[name=actor]")?.addEventListener("change", (ev) => { this.actorId = ev.target.value; });
    }

    static async #run(event, target) {
      const entry = MENU_ACTIONS.find(([key]) => key === target.dataset.key);
      if (!entry) return;
      const actor = game.actors.get(this.element.querySelector("select[name=actor]")?.value ?? this.actorId) ?? null;
      if (!actor && entry[0] !== "import") return ui.notifications.warn(t("Notify.NoActor"));
      try { await entry[3](actor); } catch (err) {
        console.error(`${MODULE_ID} |`, err);
        ui.notifications.error(`JJK 5e: ${err.message ?? err}`);
      }
    }
  };
}

function toggleMenu() {
  JJKMenuApp ??= new (makeMenuClass())();
  if (JJKMenuApp.rendered) return JJKMenuApp.close();
  return JJKMenuApp.render({ force: true });
}

Hooks.on("getSceneControlButtons", (controls) => {
  if (game.system?.id !== "dnd5e" || !game.settings.settings.has(`${MODULE_ID}.sceneTools`) || !setting("sceneTools")) return;
  const tokens = controls?.tokens;
  if (!tokens?.tools) return;
  tokens.tools.jjk5eMenu = {
    name: "jjk5eMenu", icon: "fa-solid fa-yin-yang", title: "JJK5E.SceneTools.Menu",
    order: Object.keys(tokens.tools).length, button: true, visible: true,
    onChange: () => toggleMenu()
  };
});

Hooks.on("controlToken", () => { if (JJKMenuApp?.rendered) JJKMenuApp.render(); });

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "sceneTools", {
    name: "JJK5E.Settings.sceneTools.Name", hint: "JJK5E.Settings.sceneTools.Hint",
    scope: "client", config: true, type: Boolean, default: true,
    onChange: () => ui.controls?.render?.({ reset: true })
  });
  Object.assign(game.modules.get(MODULE_ID).api ?? {}, { toggleMenu, fxData, fxChanges });
});
