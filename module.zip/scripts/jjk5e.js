/**
 * Jujutsu Kaisen 5e (V.6) — Foundry VTT module for the dnd5e system (4.x / 5.x).
 *
 * - Importer: builds world compendiums from the bundled JSON data.
 * - Cursed Energy: pool items, automatic spending, token bar sync, CE ability (WIS/CHA).
 * - Innate Techniques: choose + auto-grant on level-up, damage / speed scaling.
 * - Black Flash (check, ×3 critical dice), The Zone (crit range, advantage), Domain Expansion (sure-hit notes,
 *   Technique Burnout), Maximum / Reduced Output, Soul Awareness, Limb Damage, summons.
 * - JJK panel on character sheets, Spanish / English UI, effect expiry (unless Times Up is active).
 */
const MODULE_ID = "jjk5e";
const DATA_VERSION = "1.8.0";
const FOLDER_NAME = "JJK 5e V.6";
const ICONS = `modules/${MODULE_ID}/icons`;

const log = (...args) => console.log(`${MODULE_ID} |`, ...args);

/* -------------------------------------------- */
/*  Helpers                                      */
/* -------------------------------------------- */

/** Localize "JJK5E.<key>" with optional data; falls back to the key. */
function t(key, data) {
  const k = `JJK5E.${key}`;
  if (!game.i18n?.has?.(k)) return data ? `${key} ${JSON.stringify(data)}` : key;
  return data ? game.i18n.format(k, data) : game.i18n.localize(k);
}

const docClass = (type) => CONFIG[type]?.documentClass ?? globalThis[type];
const setting = (key) => game.settings.get(MODULE_ID, key);
const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function getCompendiumClass() {
  return foundry.documents?.collections?.CompendiumCollection ?? globalThis.CompendiumCollection;
}

async function confirmDialog(title, content) {
  const DialogV2 = foundry.applications?.api?.DialogV2;
  if (DialogV2) return DialogV2.confirm({ window: { title }, content, rejectClose: false });
  return Dialog.confirm({ title, content });
}

/** Prompt with a form; returns the named field value (or null). */
async function promptField(title, content, field, asNumber = false) {
  const read = (root) => {
    const el = root?.querySelector?.(`[name="${field}"]`) ?? root?.elements?.[field];
    if (!el) return null;
    return asNumber ? el.valueAsNumber : el.value;
  };
  const DialogV2 = foundry.applications?.api?.DialogV2;
  if (DialogV2) {
    return DialogV2.prompt({
      window: { title }, content, rejectClose: false,
      ok: { label: t("Common.OK"), callback: (event, button) => read(button.form) }
    });
  }
  return Dialog.prompt({ title, content, rejectClose: false, callback: (html) => read(html[0]) });
}

async function promptNumber(title, label, value = 1) {
  const content = `<p>${label}</p><input type="number" name="amount" value="${value}" min="0" step="1" style="width:100%">`;
  return Number(await promptField(title, content, "amount", true)) || 0;
}

async function fetchJSON(path) {
  const response = await fetch(`modules/${MODULE_ID}/${path}`);
  if (!response.ok) throw new Error(`Could not load ${path} (${response.status})`);
  return response.json();
}

function folderDepth(folder, byId) {
  let depth = 0;
  let current = folder;
  while (current?.folder) {
    depth += 1;
    current = byId.get(current.folder);
  }
  return depth;
}

function pickActor(actor) {
  return actor ?? canvas?.tokens?.controlled?.[0]?.actor ?? game.user.character ?? null;
}

function requireActor(actor) {
  actor = pickActor(actor);
  if (!actor) ui.notifications.warn(t("Notify.NoActor"));
  return actor;
}

async function chat(actor, content, extra = {}) {
  const Chat = docClass("ChatMessage");
  return Chat.create({ speaker: Chat.getSpeaker({ actor }), content, ...extra });
}

/* -------------------------------------------- */
/*  Importer                                     */
/* -------------------------------------------- */

async function importAll() {
  if (!game.user.isGM) return;
  const CompendiumCollection = getCompendiumClass();
  const manifest = await fetchJSON("data/manifest.json");

  let compendiumFolder = game.folders.find((f) => f.type === "Compendium" && f.name === FOLDER_NAME);
  if (!compendiumFolder) {
    try {
      compendiumFolder = await docClass("Folder").create({ name: FOLDER_NAME, type: "Compendium", color: "#4b1d6e" });
    } catch (err) {
      log("Compendium folders not supported, skipping.", err);
    }
  }

  ui.notifications.info(t("Import.Start", { n: manifest.length }));
  for (const entry of manifest) {
    const data = await fetchJSON(entry.file);
    const collectionId = `world.${entry.name}`;
    let pack = game.packs.get(collectionId);
    if (!pack) {
      pack = await CompendiumCollection.createCompendium({
        label: entry.label, name: entry.name, type: entry.type, package: "world"
      });
    }
    if (pack.locked) await pack.configure({ locked: false });

    const DocumentClass = docClass(entry.type);
    const FolderClass = docClass("Folder");

    const index = await pack.getIndex();
    const oldIds = index.map((i) => i._id);
    if (oldIds.length) await DocumentClass.deleteDocuments(oldIds, { pack: collectionId });
    const oldFolders = [...(pack.folders?.values?.() ?? [])].map((f) => f.id ?? f._id);
    if (oldFolders.length) await FolderClass.deleteDocuments(oldFolders, { pack: collectionId });

    const byId = new Map(data.folders.map((f) => [f._id, f]));
    const sorted = [...data.folders].sort((a, b) => folderDepth(a, byId) - folderDepth(b, byId));
    const depths = [...new Set(sorted.map((f) => folderDepth(f, byId)))];
    for (const depth of depths) {
      const level = sorted.filter((f) => folderDepth(f, byId) === depth).map((f) => ({ ...f, type: entry.type }));
      await FolderClass.createDocuments(level, { pack: collectionId, keepId: true });
    }

    const docs = data.documents;
    for (let i = 0; i < docs.length; i += 100) {
      await DocumentClass.createDocuments(docs.slice(i, i + 100), { pack: collectionId, keepId: true });
    }

    if (compendiumFolder && typeof pack.setFolder === "function") {
      try { await pack.setFolder(compendiumFolder); } catch (err) { log("setFolder failed", err); }
    }
    await pack.configure({ locked: true });
    log(`Imported ${docs.length} documents into ${collectionId}`);
  }

  await game.settings.set(MODULE_ID, "importedVersion", DATA_VERSION);
  ui.notifications.info(t("Import.Done"));
}

async function promptImport(reimport = false) {
  const ok = await confirmDialog("JJK 5e V.6", reimport ? t("Import.ConfirmUpdate") : t("Import.ConfirmNew"));
  if (ok) await importAll();
}

const AppV2 = foundry.applications?.api?.ApplicationV2;
class JJKImportMenu extends (AppV2 ?? FormApplication) {
  async render() {
    promptImport(true);
    return this;
  }
}

/* -------------------------------------------- */
/*  Cursed Energy pool                           */
/* -------------------------------------------- */

function findPool(actor) {
  if (!actor) return null;
  const pools = actor.items.filter((i) => i.flags?.jjk5e?.cePool);
  if (!pools.length) return null;
  return pools.sort((a, b) => (Number(b.system.uses?.max) || 0) - (Number(a.system.uses?.max) || 0))[0];
}

function poolValue(pool) {
  const uses = pool.system.uses ?? {};
  if (Number.isFinite(uses.value)) return uses.value;
  return (Number(uses.max) || 0) - (Number(uses.spent) || 0);
}

function poolMax(pool) {
  return Number(pool?.system.uses?.max) || 0;
}

function ceAbility(actor) {
  const a = actor.system.abilities ?? {};
  return actor.getFlag(MODULE_ID, "ceAbility") ?? ((a.cha?.mod ?? 0) > (a.wis?.mod ?? 0) ? "cha" : "wis");
}

function ceMod(actor) {
  return Number(actor.system.abilities?.[ceAbility(actor)]?.mod) || 0;
}

function activityCost(activity) {
  const costs = activity?.item?.flags?.jjk5e?.ceCosts;
  return Number(costs?.[activity.id] ?? 0);
}

async function spendCE(actor, amount, label = "") {
  const pool = findPool(actor);
  if (!pool) {
    ui.notifications.warn(t("Notify.NoPool", { name: actor?.name ?? "?" }));
    return false;
  }
  const value = poolValue(pool);
  const spent = Number(pool.system.uses?.spent) || 0;
  const max = poolMax(pool);
  const newSpent = clamp(spent + amount, 0, max);
  await pool.update({ "system.uses.spent": newSpent });
  const remaining = max - newSpent;
  if (setting("ceChat")) {
    const verb = amount >= 0 ? `−${amount}` : `+${-amount}`;
    await chat(actor, `<p><strong>${esc(label || t("CE.Name"))}</strong>: ${verb} CE `
      + `<span style="opacity:.8">(${t("CE.Remaining", { value: remaining, max })}${value < amount ? `, ${t("CE.Overspent")}` : ""})</span></p>`);
  }
  return true;
}

/* ---- token bar / actor resource sync ---- */

function resourceSlot() {
  const s = setting("ceResource");
  return s && s !== "none" ? s : null;
}

async function syncResource(actor) {
  const slot = resourceSlot();
  if (!slot || !actor?.isOwner) return;
  const pool = findPool(actor);
  if (!pool) return;
  const value = poolValue(pool);
  const max = poolMax(pool);
  const cur = actor.system.resources?.[slot] ?? {};
  const label = t("CE.Name");
  if (cur.value !== value || cur.max !== max || cur.label !== label) {
    await actor.update({
      [`system.resources.${slot}`]: { value, max, label, sr: false, lr: false }
    }, { jjk5eSync: true });
  }
  if (setting("autoTokenBar")) {
    const attr = `resources.${slot}`;
    try {
      if (!actor.isToken && !actor.prototypeToken?.bar2?.attribute) {
        await actor.update({ "prototypeToken.bar2.attribute": attr }, { jjk5eSync: true });
      }
      for (const tok of actor.getActiveTokens(false, true)) {
        if (!tok.bar2?.attribute && tok.isOwner) await tok.update({ "bar2.attribute": attr });
      }
    } catch (err) { log("token bar", err); }
  }
}

async function onActorUpdate(actor, changes, options, userId) {
  if (userId !== game.user.id || options?.jjk5eSync) return;
  const slot = resourceSlot();
  if (!slot) return;
  const v = foundry.utils.getProperty(changes, `system.resources.${slot}.value`);
  if (v === undefined) return;
  const pool = findPool(actor);
  if (!pool) return;
  const max = poolMax(pool);
  await pool.update({ "system.uses.spent": clamp(max - Number(v), 0, max) }, { jjk5eSync: true });
}

/* -------------------------------------------- */
/*  Effects helpers                              */
/* -------------------------------------------- */

function kindEffect(actor, kind) {
  return actor.effects.find((e) => e.flags?.jjk5e?.kind === kind);
}

/** Create / update / delete (data = null) the module effect of the given kind. */
async function setKindEffect(actor, kind, data) {
  const existing = kindEffect(actor, kind);
  if (!data) {
    if (existing) await existing.delete();
    return null;
  }
  data = foundry.utils.mergeObject(data, { flags: { jjk5e: { kind } } }, { inplace: false });
  if (existing) return existing.update(data);
  const created = await actor.createEmbeddedDocuments("ActiveEffect", [data]);
  return created?.[0] ?? null;
}

const hasKind = (actor, kind) => !!actor?.effects?.some((e) => e.flags?.jjk5e?.kind === kind && !e.disabled);
const domainOpen = (actor) => !!actor?.effects?.some((e) => (e.flags?.jjk5e?.kind === "domain" || e.flags?.jjk5e?.domainOpen) && !e.disabled);
const inBurnout = (actor) => !!actor?.effects?.some((e) => (e.flags?.jjk5e?.kind === "burnout" || e.flags?.jjk5e?.burnout) && !e.disabled);
const zoneEffect = (actor) => actor?.effects?.find((e) => e.flags?.jjk5e?.kind === "zone" || e.flags?.jjk5e?.zone);

/* -------------------------------------------- */
/*  Activity hooks (CE, burnout, sure-hit)       */
/* -------------------------------------------- */

const RO_MAX = [null, null, null, 8, 8, 8, 6, 6, 6, 3];
const RO_ROWS = [
  "", "-1 Output", "-2 Output, Die Tier (-1)", "-3 Output, 8 Max", "-4 Output, Die Tier (-2)",
  "-5 Output, AP (75%)", "-6 Output, 6 Max, Die Tier (-3)", "-7 Output, DR (50%)", "-8 Output, AP (50%)",
  "-9 Output, 3 Max, Die Tier (-4)"
];

function registerActivityHooks() {
  Hooks.on("dnd5e.preUseActivity", (activity) => {
    const actor = activity.actor ?? activity.item?.actor;
    if (activity.item?.flags?.jjk5e?.mindset && actor && !actor.system.attributes?.inspiration) {
      ui.notifications.warn(t("Notify.NoInspiration", { name: actor.name }));
      return false;
    }
    if (activity.item?.flags?.jjk5e?.technique && inBurnout(actor)) {
      ui.notifications.warn(t("Notify.Burnout"));
      return false;
    }
    const cost = activityCost(activity);
    const ro = Number(actor?.getFlag(MODULE_ID, "reducedOutput")) || 0;
    if (cost && RO_MAX[ro] && cost > RO_MAX[ro]) {
      ui.notifications.warn(t("Notify.ROMax", { cost, max: RO_MAX[ro], level: ro }));
      return false;
    }
    if (!setting("autoSpendCE") || !cost) return;
    const pool = findPool(actor);
    if (!pool) {
      ui.notifications.warn(t("Notify.NoPoolNotSpent", { name: actor?.name ?? "?" }));
      return;
    }
    if (poolValue(pool) < cost) {
      ui.notifications.warn(t("Notify.NotEnoughCE", { value: poolValue(pool), cost }));
      return false;
    }
  });

  Hooks.on("dnd5e.postUseActivity", async (activity, usageConfig) => {
    const actor = activity.actor ?? activity.item?.actor;
    const item = activity.item;
    await remindModifiers(actor, item);
    if (item?.flags?.jjk5e?.openTechnique) await chooseTechnique(actor);
    const grp = item?.flags?.jjk5e?.activatesGroup?.[activity.id];
    if (grp && actor) await activateGroup(actor, grp);
    if (item?.flags?.jjk5e?.mindset && actor?.system.attributes?.inspiration) {
      await actor.update({ "system.attributes.inspiration": false });
      await chat(actor, `<p><strong>${esc(item.name)}</strong> — ${t("Feats.InspirationUsed")}</p>`);
    }
    if (item?.flags?.jjk5e?.domainActivity === activity.id) await openDomain(actor, item);
    else if (item?.flags?.jjk5e?.technique && domainOpen(actor) && setting("domainSureHit")
      && ["attack", "save"].includes(activity.type)) {
      await chat(actor, `<p><strong>${t("Domain.SureHit")}</strong> — ${activity.type === "attack"
        ? t("Domain.SureHitAttack") : t("Domain.SureHitSave")}</p>`);
    }
    if (!setting("autoSpendCE")) return;
    let cost = activityCost(activity);
    if (!cost) return;
    const step = Number(item?.flags?.jjk5e?.ceSteps?.[activity.id] ?? 0);
    const extra = Number(usageConfig?.scaling) || 0;
    if (step && extra > 0) cost += step * extra;
    if (!findPool(actor)) return;
    await spendCE(actor, cost, `${item.name}${activity.name ? ` — ${activity.name}` : ""}`);
  });
}

/* -------------------------------------------- */
/*  Feat links: reminders & prerequisites        */
/* -------------------------------------------- */

const normName = (n) => String(n ?? "").toLowerCase().replace(/[’']/g, "").replace(/\s*:\s*/g, ":").replace(/[^a-z0-9#:]+/g, " ").trim();
const plainText = (htmlStr) => String(htmlStr ?? "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();

function modifiersFor(actor, item) {
  const target = normName(item.name);
  return actor.items.filter((i) => i.id !== item.id && ((i.flags?.jjk5e?.prereq?.features ?? [])
    .some((group) => group.some((n) => normName(n) === target))
    || (i.flags?.jjk5e?.modifies ?? []).some((n) => normName(n) === target)));
}

async function remindModifiers(actor, item) {
  if (!setting("modifierReminders") || !actor || !item) return;
  const mods = modifiersFor(actor, item);
  if (!mods.length) return;
  const rows = mods.map((m) => {
    let txt = plainText(String(m.system.description?.value ?? "").replace(/<p>\s*<em>[\s\S]*?<\/em>\s*<\/p>/gi, ""));
    if (txt.length > 260) txt = `${txt.slice(0, 257)}…`;
    return `<li><strong>${esc(m.name)}</strong>: ${esc(txt)}</li>`;
  }).join("");
  await chat(actor, `<p><strong>${t("Feats.ModifiedBy", { name: esc(item.name) })}</strong></p><ul>${rows}</ul>`);
}

function missingPrereqs(actor, item) {
  const pre = item.flags?.jjk5e?.prereq;
  if (!pre) return [];
  const missing = [];
  const names = new Set(actor.items.map((i) => normName(i.name)));
  for (const group of pre.features ?? []) {
    if (!group.some((n) => names.has(normName(n)))) missing.push(group.join(t("Feats.Or")));
  }
  const techs = new Set([actor.getFlag(MODULE_ID, "technique"), ...actor.items.map((i) => i.flags?.jjk5e?.technique)]
    .filter(Boolean).map(normName));
  for (const group of pre.techniques ?? []) {
    if (!group.some((n) => techs.has(normName(n)))) missing.push(group.join(t("Feats.Or")));
  }
  for (const group of pre.prefixes ?? []) {
    if (!group.some((p) => [...names].some((n) => n.startsWith(normName(p))))) missing.push(group.join(t("Feats.Or")));
  }
  for (const group of pre.options ?? []) {
    const found = group.some((lab) => actor.items.some((i) => new RegExp(`<strong>\\s*${lab.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "i")
      .test(i.system.description?.value ?? "")));
    if (!found) missing.push(group.join(t("Feats.Or")));
  }
  if (pre.ceScore) {
    const score = Number(actor.system.abilities?.[ceAbility(actor)]?.value) || 0;
    if (score < pre.ceScore) missing.push(t("Feats.CEScore", { need: pre.ceScore, have: score }));
  }
  if (pre.level && characterLevel(actor) < pre.level) missing.push(t("Feats.Level", { need: pre.level }));
  if (pre.skill && !(Number(actor.system.skills?.[pre.skill]?.value) >= 1)) missing.push(t("Feats.Skill", { skill: pre.skill }));
  for (const [ab, need] of Object.entries(pre.abilities ?? {})) {
    const have = Number(actor.system.abilities?.[ab]?.value) || 0;
    if (have < need) missing.push(t("Feats.Ability", { ability: ab.toUpperCase(), need, have }));
  }
  // Heavenly Restriction body points & per-category limits
  const cost = Number(item.flags?.jjk5e?.bodyCost) || 0;
  if (cost) {
    const hr = actor.items.find((i) => i.type === "class" && i.system.identifier === "heavenly-restriction");
    const bonus = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.bodyPointBonus) || 0), 0);
    const budget = (Number(hr?.system.levels) || 0) + bonus;
    const used = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.bodyCost) || 0), 0);
    if (used + cost > budget) missing.push(t("Feats.BodyPoints", { used, cost, budget }));
    const cat = item.flags.jjk5e.bodyCategory;
    const limit = Number(actor.system.abilities?.[cat]?.mod) || 0;
    const count = actor.items.filter((i) => i.flags?.jjk5e?.bodyCategory === cat).length;
    if (cat && count + 1 > limit) missing.push(t("Feats.BodyCategory", { ability: cat.toUpperCase(), limit }));
  }
  return missing;
}

function onPreCreateItem(item, data, options, userId) {
  if (userId !== game.user.id || !setting("checkPrereqs")) return;
  const actor = item.parent;
  if (actor?.documentName !== "Actor" || options?.jjk5eSkipPrereq) return;
  const missing = missingPrereqs(actor, item);
  if (missing.length) ui.notifications.warn(t("Feats.Missing", { name: item.name, list: missing.join("; ") }), { permanent: false });
}

/* -------------------------------------------- */
/*  Activation groups (Focus, Fury, Reckless…)   */
/* -------------------------------------------- */

function groupEffects(actor, group) {
  const out = [];
  for (const item of actor.items) for (const e of item.effects ?? []) if (e.flags?.jjk5e?.group === group) out.push(e);
  return out;
}

function activeGroups(actor) {
  const set = new Set();
  for (const item of actor.items) for (const e of item.effects ?? []) {
    if (e.flags?.jjk5e?.group && !e.disabled) set.add(e.flags.jjk5e.group);
  }
  return [...set];
}

async function activateGroup(actor, group) {
  const endless = group === "focus" && actor.items.some((i) => i.name === "Endless Focus");
  const duration = group === "reckless" ? { rounds: 1, turns: 0 } : (endless ? {} : { seconds: 60, rounds: 10 });
  const start = { startTime: game.time?.worldTime ?? 0, startRound: game.combat?.round ?? null, startTurn: game.combat?.turn ?? null };
  for (const e of groupEffects(actor, group)) {
    await e.update({ disabled: false, duration: { ...duration, ...(Object.keys(duration).length ? start : {}) } });
  }
}

async function endGroup(actor, group) {
  for (const e of groupEffects(actor, group)) if (!e.disabled) await e.update({ disabled: true });
}

/* -------------------------------------------- */
/*  Innate Techniques                            */
/* -------------------------------------------- */

const TECH_PACK = "world.jjk5e-techniques";

function techniqueLevel(actor) {
  const classes = actor.items.filter((i) => i.type === "class" && i.system.identifier !== "heavenly-restriction");
  return Math.max(0, ...classes.map((c) => Number(c.system.levels) || 0));
}

function characterLevel(actor) {
  return Number(actor.system?.details?.level) || techniqueLevel(actor) || 0;
}

async function techniqueIndex() {
  const pack = game.packs.get(TECH_PACK);
  if (!pack) {
    ui.notifications.error(t("Notify.NoTechPack"));
    return null;
  }
  const index = await pack.getIndex({ fields: ["flags.jjk5e"] });
  return { pack, index };
}

async function syncTechnique(actor, { notify = true } = {}) {
  const name = actor?.getFlag(MODULE_ID, "technique");
  if (!name) return 0;
  const lvl = techniqueLevel(actor);
  const data = await techniqueIndex();
  if (!data) return 0;
  const owned = new Set(actor.items.filter((i) => i.flags?.jjk5e?.technique === name).map((i) => i.name));
  const ids = data.index
    .filter((e) => e.flags?.jjk5e?.technique === name && (e.flags.jjk5e.level ?? 99) <= lvl && !owned.has(e.name))
    .map((e) => e._id);
  if (!ids.length) return 0;
  const docs = await Promise.all(ids.map((id) => data.pack.getDocument(id)));
  const toCreate = docs.filter(Boolean).map((d) => {
    const obj = d.toObject();
    foundry.utils.setProperty(obj, "_stats.compendiumSource", d.uuid);
    foundry.utils.setProperty(obj, "flags.core.sourceId", d.uuid);
    return obj;
  });
  await actor.createEmbeddedDocuments("Item", toCreate, { jjk5eSkipPrereq: true });
  if (notify) ui.notifications.info(t("Notify.Gained", { name: actor.name, list: toCreate.map((d) => d.name).join(", ") }));
  return toCreate.length;
}

function isHeavenlyOnly(actor) {
  const classes = actor.items.filter((i) => i.type === "class");
  return classes.length > 0 && classes.every((c) => c.system.identifier === "heavenly-restriction");
}

async function chooseTechnique(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  if (!actor.isOwner) return ui.notifications.warn(t("Notify.NotOwner"));
  if (isHeavenlyOnly(actor)) return ui.notifications.warn(t("Notify.HRNoTechnique"));
  const data = await techniqueIndex();
  if (!data) return;
  const names = [...new Set(data.index.map((e) => e.flags?.jjk5e?.technique).filter(Boolean))].sort();
  const current = actor.getFlag(MODULE_ID, "technique");
  const options = names.map((n) => `<option value="${esc(n)}" ${n === current ? "selected" : ""}>${esc(n)}</option>`).join("");
  const content = `<p>${t("Technique.Prompt", { name: esc(actor.name), level: techniqueLevel(actor) })}</p>`
    + `<select name="technique" style="width:100%">${options}</select>`
    + (current ? `<p><em>${t("Technique.Current", { name: esc(current) })}</em></p>` : "");
  const choice = await promptField(t("Technique.Title"), content, "technique");
  if (!choice) return;
  await actor.setFlag(MODULE_ID, "technique", choice);
  if (!actor.getFlag(MODULE_ID, "ceAbility")) await chooseCEAbility(actor);
  const added = await syncTechnique(actor);
  await applyScaling(actor);
  if (!added) ui.notifications.info(t("Notify.TechniqueSet", { name: actor.name, technique: choice }));
}

async function promptCE(mode = "spend", actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const n = await promptNumber(mode === "spend" ? t("CE.SpendTitle") : t("CE.RegainTitle"), t("CE.Amount"));
  if (!n) return;
  return mode === "spend" ? spendCE(actor, n, t("CE.Spent")) : spendCE(actor, -n, t("CE.Regained"));
}

async function shortRestCE(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const classes = actor.items.filter((i) => i.type === "class");
  const maxHD = classes.reduce((tot, c) => tot + (Number(c.system.levels) || 0), 0);
  const cap = Math.floor(maxHD / 2);
  const n = Math.min(cap, await promptNumber(t("CE.ShortRestTitle"), t("CE.ShortRestPrompt", { cap })));
  if (n > 0) await spendCE(actor, -n, t("CE.ShortRestLabel", { n }));
}

async function negativeEmotion(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const pb = Number(actor.system.attributes?.prof) || 2;
  return spendCE(actor, -pb, t("CE.NegativeEmotion"));
}

/* -------------------------------------------- */
/*  Level scaling                                */
/* -------------------------------------------- */

const CE_TOKEN = "max(@abilities.wis.mod, @abilities.cha.mod)";

async function applyScaling(actor) {
  if (!actor?.isOwner) return;
  const lvl = techniqueLevel(actor) || characterLevel(actor);
  for (const item of actor.items) {
    const table = item.flags?.jjk5e?.dmgScale;
    if (!table) continue;
    const src = item.toObject().system.activities ?? {};
    const update = {};
    for (const [aid, tiers] of Object.entries(table)) {
      const parts = src[aid]?.damage?.parts;
      if (!parts?.length) continue;
      const tier = tiers.filter(([l]) => l <= lvl).pop();
      const m = tier && /^(\d+)d(\d+)$/.exec(tier[1]);
      if (!m) continue;
      if (parts[0].number === Number(m[1]) && parts[0].denomination === Number(m[2])) continue;
      parts[0].number = Number(m[1]);
      parts[0].denomination = Number(m[2]);
      update[`system.activities.${aid}.damage.parts`] = parts;
    }
    if (Object.keys(update).length) await item.update(update);
  }
  const rollData = actor.getRollData();
  for (const item of actor.items) {
    for (const effect of item.effects ?? []) {
      const lt = effect.flags?.jjk5e?.levelTable;
      if (lt) {
        const cls = actor.items.find((i) => i.type === "class" && i.system.identifier === lt.class);
        const lvl = lt.class === "*" ? characterLevel(actor) : (Number(cls?.system.levels) || 0);
        const row = lt.table.filter(([l]) => l <= lvl).pop();
        const v = String(row ? row[1] : 0);
        const keys = lt.keys ?? null;
        const changes = effect.changes.map((c) => (!keys || keys.includes(c.key) ? { ...c, value: v } : c));
        if (changes.some((c, i) => c.value !== effect.changes[i].value)) await effect.update({ changes });
      }
    }
  }
  for (const item of actor.items) {
    for (const effect of item.effects ?? []) {
      const key = effect.flags?.jjk5e?.scaleKey;
      if (!key) continue;
      const sv = foundry.utils.getProperty(rollData, `scale.${key}`);
      const value = Number(sv?.value ?? sv);
      if (!Number.isFinite(value)) continue;
      const changes = effect.changes.map((c) => ({ ...c, value: String(value) }));
      if (changes.some((c, i) => c.value !== effect.changes[i].value)) await effect.update({ changes });
    }
  }
  const ab = actor.getFlag(MODULE_ID, "ceAbility");
  const abTok = `@abilities.${ab ?? ceAbility(actor)}.mod`;
  const bonusParts = actor.items.map((i) => i.flags?.jjk5e?.ceMaxBonus).filter((b) => b !== undefined && b !== null && b !== 0)
    .map((b) => (typeof b === "number" ? String(b) : `(${String(b).split(CE_TOKEN).join(abTok)})`));
  for (const pool of actor.items.filter((i) => i.flags?.jjk5e?.cePool)) {
    const srcMax = String(pool.toObject().system.uses?.max ?? "");
    let base = pool.flags.jjk5e.baseMax ?? srcMax;
    if (ab) base = base.split(CE_TOKEN).join(`@abilities.${ab}.mod`);
    const desired = bonusParts.length ? `${base} + ${bonusParts.join(" + ")}` : base;
    if (desired !== srcMax || pool.flags.jjk5e.baseMax !== base) {
      await pool.update({ "system.uses.max": desired, "flags.jjk5e.baseMax": base });
    }
  }
  if (ab) {
    for (const item of actor.items) {
      if (item.flags?.jjk5e?.cePool) continue;
      const json = JSON.stringify(item.toObject().system);
      if (!json.includes(CE_TOKEN)) continue;
      await item.update({ system: JSON.parse(json.split(CE_TOKEN).join(`@abilities.${ab}.mod`)) });
    }
  }
  await applyCEEffects(actor);
  await syncResource(actor);
}

const UD_NAMES = ["unarmored defense", "restrained body", "hard shell", "integrated armor"];

/** Effects whose values depend on the CE modifier, and the CE score bonus (Immense Cursed Energy). */
async function applyCEEffects(actor) {
  const ab = ceAbility(actor);
  const mod = `@abilities.${ab}.mod`;
  const hasUD = actor.items.some((i) => UD_NAMES.includes(i.name.toLowerCase()) && i.flags?.jjk5e);
  for (const item of actor.items) {
    for (const effect of item.effects ?? []) {
      const tpls = effect.flags?.jjk5e?.ceChanges;
      let changes = effect.changes;
      let dirty = false;
      if (tpls?.length) {
        changes = tpls.map((c) => ({ key: c.key, mode: c.mode, priority: null,
          value: c.tpl.replace("{CEHALF}", hasUD ? `ceil(${mod} / 2)` : mod).replace("{CE}", mod) }));
        dirty = JSON.stringify(changes.map((c) => c.value)) !== JSON.stringify(effect.changes.map((c) => c.value));
      } else if (effect.changes.some((c) => String(c.value).includes(CE_TOKEN))) {
        changes = effect.changes.map((c) => ({ ...c, value: String(c.value).split(CE_TOKEN).join(mod) }));
        dirty = true;
      }
      if (dirty) await effect.update({ changes });
    }
    const bonus = Number(item.flags?.jjk5e?.ceScoreBonus) || 0;
    if (!bonus) continue;
    const key = `system.abilities.${ab}.value`;
    const existing = item.effects?.find((e) => e.flags?.jjk5e?.kind === "ceScore");
    const data = { name: `${item.name}: CE score +${bonus}`, img: item.img, transfer: true, disabled: false,
      changes: [{ key, mode: 2, value: String(bonus), priority: null }], flags: { jjk5e: { kind: "ceScore" } } };
    if (!existing) await item.createEmbeddedDocuments("ActiveEffect", [data]);
    else if (existing.changes?.[0]?.key !== key) await existing.update({ changes: data.changes });
  }
}

async function chooseCEAbility(actor) {
  actor = requireActor(actor);
  if (!actor) return null;
  const a = actor.system.abilities;
  const current = ceAbility(actor);
  const content = `<p>${t("CE.AbilityPrompt", { name: esc(actor.name) })}</p>`
    + `<select name="ability" style="width:100%">`
    + `<option value="wis" ${current === "wis" ? "selected" : ""}>${t("Common.Wisdom")} (${a.wis?.mod ?? 0})</option>`
    + `<option value="cha" ${current === "cha" ? "selected" : ""}>${t("Common.Charisma")} (${a.cha?.mod ?? 0})</option></select>`;
  const choice = await promptField(t("CE.AbilityTitle"), content, "ability");
  if (!choice) return null;
  const old = actor.getFlag(MODULE_ID, "ceAbility");
  await actor.update({ "system.attributes.spellcasting": choice, [`flags.${MODULE_ID}.ceAbility`]: choice });
  if (old && old !== choice) {
    const from = `@abilities.${old}.mod`;
    for (const item of actor.items) {
      const json = JSON.stringify(item.toObject().system);
      if (item.flags?.jjk5e && json.includes(from)) {
        await item.update({ system: JSON.parse(json.split(from).join(`@abilities.${choice}.mod`)) });
      }
      const bm = item.flags?.jjk5e?.baseMax;
      if (bm?.includes(from)) await item.update({ "flags.jjk5e.baseMax": bm.split(from).join(`@abilities.${choice}.mod`) });
    }
  }
  await applyScaling(actor);
  ui.notifications.info(t("Notify.CEAbility", { name: actor.name, ability: choice.toUpperCase() }));
  return choice;
}

/* -------------------------------------------- */
/*  Black Flash & The Zone                       */
/* -------------------------------------------- */

const handledRolls = new WeakSet();

async function onAttackRoll(rolls, subject) {
  if (!setting("blackFlash")) return;
  const roll = Array.isArray(rolls) ? rolls[0] : rolls;
  if (!roll || handledRolls.has(roll)) return;
  handledRolls.add(roll);
  const activity = subject?.activity ?? subject;
  const actor = activity?.actor ?? activity?.item?.actor ?? activity?.parent?.actor;
  if (!actor?.isOwner) return;
  if (!roll.isCritical) {
    if (actor.getFlag(MODULE_ID, "pendingBlackFlash")) await actor.unsetFlag(MODULE_ID, "pendingBlackFlash");
    return;
  }
  if (actor.type !== "character" || isHeavenlyOnly(actor)) return;
  const kind = activity?.attack?.type?.value ?? activity?.actionType;
  if (kind && !["melee", "mwak", "msak"].includes(kind)) return;
  const zone = zoneEffect(actor);
  const stacks = Number(zone?.flags?.jjk5e?.zone) || 0;
  const bonusRange = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.blackFlashRange) || 0), 0);
  const target = Math.max(2, 20 - stacks - bonusRange);
  const check = await new Roll("1d20").evaluate();
  const success = check.total >= target;
  const Chat = docClass("ChatMessage");
  await check.toMessage({
    speaker: Chat.getSpeaker({ actor }),
    flavor: `<strong>${t("BlackFlash.Check")}</strong> (${t("BlackFlash.Needs", { target })})`
      + (success ? `<h3 style="color:#b00;text-align:center">⚡ BLACK FLASH ⚡</h3><p>${t("BlackFlash.Success")}</p>` : "")
  });
  if (!success) return;
  if (setting("blackFlashDamage")) await actor.setFlag(MODULE_ID, "pendingBlackFlash", true);
  const next = stacks + 1;
  await setKindEffect(actor, "zone", {
    name: `${t("Zone.Name")}${next > 1 ? ` ×${next}` : ""}`, img: `${ICONS}/zone.svg`,
    duration: { rounds: 10, seconds: 60 },
    changes: [
      { key: "flags.dnd5e.weaponCriticalThreshold", mode: 3, value: String(20 - next) },
      { key: "flags.dnd5e.spellCriticalThreshold", mode: 3, value: String(20 - next) }
    ],
    description: `<p>${t("Zone.Description")}</p>`,
    flags: { jjk5e: { zone: next } }
  });
  const burnout = actor.effects.filter((e) => e.flags?.jjk5e?.kind === "burnout" || e.flags?.jjk5e?.burnout).map((e) => e.id);
  if (burnout.length) await actor.deleteEmbeddedDocuments("ActiveEffect", burnout);
  const ro = Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0;
  if (ro > 0) await setReducedOutput(actor, ro - 1);
}

function traitChoice(actor, flag) {
  for (const item of actor.items) {
    const e = item.effects?.find((x) => x.flags?.jjk5e?.[flag] && !x.disabled);
    if (e) return e.flags.jjk5e[flag];
  }
  return null;
}

function addPart(config, part) {
  const roll = config?.rolls?.[0];
  if (!roll) return;
  roll.parts ??= [];
  roll.parts.push(part);
}

function onPreRollAttack(config) {
  const actor = config?.subject?.actor ?? config?.subject?.item?.actor;
  if (!actor) return;
  if (setting("zoneAdvantage") && zoneEffect(actor) && !zoneEffect(actor).disabled) config.advantage = true;
  const melee = (config?.subject?.attack?.type?.value ?? config?.subject?.actionType) === "melee"
    || ["mwak", "msak"].includes(config?.subject?.actionType);
  if (melee && activeGroups(actor).includes("reckless")) config.advantage = true;
  if (config?.subject?.item?.flags?.jjk5e?.rawCE && traitChoice(actor, "ceTrait") === "rough") addPart(config, "1");
}

function rawCEDamageBonus(actor) {
  const mastery = traitChoice(actor, "ceMastery");
  const trait = traitChoice(actor, "ceTrait");
  const parts = [];
  if (mastery === "rough") parts.push(`2 + @abilities.${ceAbility(actor)}.mod`);
  else if (trait === "rough") parts.push("2");
  if (trait === "elemental") parts.push("@prof");
  return parts;
}

function onPreRollDamage(config) {
  const actor = config?.subject?.actor ?? config?.subject?.item?.actor;
  if (actor && config?.subject?.item?.flags?.jjk5e?.rawCE) rawCEDamageBonus(actor).forEach((p) => addPart(config, p));
  if (!setting("blackFlashDamage")) return;
  if (!actor?.getFlag?.(MODULE_ID, "pendingBlackFlash")) return;
  const critical = config.isCritical === true || (config.rolls ?? []).some((r) => r.options?.isCritical === true);
  if (!critical) return;
  for (const r of config.rolls ?? []) {
    r.options ??= {};
    r.options.critical = { ...(r.options.critical ?? {}), multiplier: 3 };
  }
  config.critical = { ...(config.critical ?? {}), multiplier: 3 };
  actor.unsetFlag(MODULE_ID, "pendingBlackFlash");
  chat(actor, `<p><strong>⚡ Black Flash</strong>: ${t("BlackFlash.Damage")}</p>`);
}

/* -------------------------------------------- */
/*  Domain Expansion & Technique Burnout         */
/* -------------------------------------------- */

async function openDomain(actor, item) {
  if (!actor?.isOwner || !setting("domainTracking")) return;
  await setKindEffect(actor, "domain", {
    name: item.name, img: `${ICONS}/domain.svg`, duration: { rounds: 10, seconds: 60 },
    description: `<p>${t("Domain.Description")}</p>`,
    flags: { jjk5e: { domainOpen: true } }
  });
}

async function closeDomain(actor) {
  const eff = actor.effects.find((e) => e.flags?.jjk5e?.kind === "domain" || e.flags?.jjk5e?.domainOpen);
  if (eff) await eff.delete();
}

async function onDeleteEffect(effect, options, userId) {
  if (userId !== game.user.id) return;
  if (!(effect.flags?.jjk5e?.domainOpen || effect.flags?.jjk5e?.kind === "domain")) return;
  if (!setting("domainTracking")) return;
  const actor = effect.parent;
  if (actor?.documentName !== "Actor") return;
  await setKindEffect(actor, "burnout", {
    name: t("Burnout.Name"), img: `${ICONS}/burnout.svg`, duration: { rounds: 10, seconds: 60 },
    changes: [{ key: "system.attributes.exhaustion", mode: 2, value: "2" }],
    description: `<p>${t("Burnout.Description")}</p>`,
    flags: { jjk5e: { burnout: true } }
  });
  ui.notifications.info(t("Notify.Burnt", { name: actor.name }));
}

/* -------------------------------------------- */
/*  Maximum / Reduced Output                     */
/* -------------------------------------------- */

async function setReducedOutput(actor, level) {
  level = clamp(Number(level) || 0, 0, 9);
  await actor.setFlag(MODULE_ID, "reducedOutput", level);
  await setKindEffect(actor, "reduced", level ? {
    name: `${t("Output.Reduced")} ${level}`, img: `${ICONS}/reduced.svg`,
    description: `<p><strong>${RO_ROWS[level]}</strong></p><p>${t("Output.ReducedDescription")}</p>`
  } : null);
  return level;
}

async function maximumOutput(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const ro = Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0;
  const base = await promptNumber(t("Output.MaxTitle"), t("Output.MaxPrompt"), 5);
  if (!base) return;
  if (base < 3) return ui.notifications.warn(t("Output.TooLow"));
  if (base < 5) ui.notifications.info(t("Output.ShikigamiOnly"));
  const combat = game.combat;
  const key = combat ? `${combat.id}:${combat.round}` : null;
  const last = actor.getFlag(MODULE_ID, "maxOutputRound");
  if (key && last === key) {
    const dc = 15 + 2 * ro;
    const r = await new Roll(`1d20 + ${ceMod(actor)}`).evaluate();
    await r.toMessage({ speaker: docClass("ChatMessage").getSpeaker({ actor }), flavor: t("Output.Check", { dc }) });
    if (r.total < dc) {
      await setReducedOutput(actor, ro + 1);
      ui.notifications.warn(t("Output.GainedRO", { level: ro + 1 }));
    }
  }
  if (key) await actor.setFlag(MODULE_ID, "maxOutputRound", key);
  const extra = Math.ceil(base / 2) + 2 * ro;
  await spendCE(actor, extra, t("Output.Max"));
  await chat(actor, `<p><strong>${t("Output.Max")}</strong> (+${extra} CE)</p>${t("Output.Benefits")}`);
}

/* -------------------------------------------- */
/*  Soul Awareness                               */
/* -------------------------------------------- */

const SOUL_ABILITIES = [
  "Minor Soul Perception", "Lesser Soul Guard", "Medium Soul Perception", "Soul Harming", "Soul Knowledge",
  "Major Soul Perception", "Soul Anchoring", "Greater Soul Guard", "Greater Soul Harming", "Soul Removal"
];

async function setSoulAwareness(actor, level) {
  level = clamp(Number(level) || 0, 0, 10);
  await actor.setFlag(MODULE_ID, "soulAwareness", level);
  const list = SOUL_ABILITIES.slice(0, level).map((n, i) => `<li>${i + 1}. ${n}</li>`).join("");
  await setKindEffect(actor, "soul", level ? {
    name: `${t("Soul.Name")} ${level}`, img: `${ICONS}/soul.svg`,
    description: `<ul>${list}</ul><p>${t("Soul.Description")}</p>`
  } : null);
  return level;
}

/* -------------------------------------------- */
/*  Limb Damage                                  */
/* -------------------------------------------- */

const LIMBS = [
  { key: "rleg", mult: 1, roll: 1 }, { key: "lleg", mult: 1, roll: 2 }, { key: "rarm", mult: 1, roll: 3 },
  { key: "larm", mult: 1, roll: 4 }, { key: "torso", mult: 2, roll: 5 }, { key: "head", mult: 2, roll: 6 }
];

function limbThreshold(actor, limb) {
  const con = Math.max(1, Number(actor.system.abilities?.con?.mod) || 0);
  return con * characterLevel(actor) * limb.mult;
}

async function setLimb(actor, key, status) {
  const limb = LIMBS.find((l) => l.key === key);
  if (!limb) return;
  const limbs = { ...(actor.getFlag(MODULE_ID, "limbs") ?? {}) };
  limbs[key] = status;
  await actor.setFlag(MODULE_ID, "limbs", limbs);
  if (status === "ok") return setKindEffect(actor, `limb:${key}`, null);
  const name = `${t(`Limb.${key}`)}: ${t(`Limb.${status}`)}`;
  const data = { name, img: `${ICONS}/limb.svg`, changes: [], statuses: [], description: `<p>${t(`Limb.Effect.${key}.${status}`)}</p>` };
  if (key === "rleg" || key === "lleg") data.changes.push({ key: "system.attributes.movement.walk", mode: 1, value: "0.5" });
  if (key === "torso" && status === "broken") {
    const max = Number(actor.system.attributes?.hp?.max) || 0;
    data.changes.push({ key: "system.attributes.hp.bonuses.overall", mode: 2, value: String(-Math.floor(max / 2)) });
  }
  if (key === "head" && status === "broken") data.statuses.push("unconscious");
  if ((key === "torso" || key === "head") && status === "lost") data.statuses.push("dead");
  await setKindEffect(actor, `limb:${key}`, data);
  await chat(actor, `<p><strong>${esc(actor.name)}</strong> — ${esc(name)}</p><p>${t(`Limb.Effect.${key}.${status}`)}</p>`);
}

async function rollLimb(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  const pack = game.packs.get("world.jjk5e-tables");
  const entry = pack && (await pack.getIndex()).find((e) => /limb/i.test(e.name));
  if (entry) {
    const table = await pack.getDocument(entry._id);
    return table.draw();
  }
  const r = await new Roll("1d6").evaluate();
  const limb = LIMBS.find((l) => l.roll === r.total);
  await r.toMessage({ speaker: docClass("ChatMessage").getSpeaker({ actor }), flavor: `${t("Limb.Roll")}: ${t(`Limb.${limb.key}`)}` });
}

/* -------------------------------------------- */
/*  Summons (shikigami, ink creatures, …)        */
/* -------------------------------------------- */

const SUMMON_ALIASES = { "ink wolf": "Wolf", "ink crow": "Giant Eagle", "killer whale": "Killer Whale" };
const SUMMON_FOLDER = "JJK Summons";

async function findSummonSource(name) {
  const n = name.trim().toLowerCase();
  const alias = (SUMMON_ALIASES[n] ?? name).toLowerCase();
  const world = game.actors.find((a) => [n, alias].includes(a.name.toLowerCase()));
  if (world) return { actor: world };
  const packs = [...(game.packs.contents ?? game.packs.values())].filter((p) => p.documentName === "Actor")
    .sort((a, b) => (b.collection.startsWith("dnd5e.") ? 1 : 0) - (a.collection.startsWith("dnd5e.") ? 1 : 0));
  for (const pack of packs) {
    const entry = (await pack.getIndex()).find((e) => [n, alias].includes(e.name.toLowerCase()));
    if (entry) return { pack, id: entry._id };
  }
  return null;
}

async function gmSummon({ actorUuid, name, count = 1, userId, sceneId }) {
  const src = await findSummonSource(name);
  if (!src) return ui.notifications.warn(t("Summon.NotFound", { name }));
  let actor = src.actor;
  if (!actor) {
    let folder = game.folders.find((f) => f.type === "Actor" && f.name === SUMMON_FOLDER);
    if (!folder) folder = await docClass("Folder").create({ name: SUMMON_FOLDER, type: "Actor" });
    actor = await game.actors.importFromCompendium(src.pack, src.id, { folder: folder.id });
  }
  if (userId && actor.ownership?.[userId] !== 3) await actor.update({ [`ownership.${userId}`]: 3 });
  const scene = game.scenes.get(sceneId) ?? canvas.scene;
  if (!scene) return;
  const summoner = await fromUuid(actorUuid);
  const baseId = summoner?.isToken ? summoner.token?.actorId : summoner?.id;
  const sTok = scene.tokens.find((tk) => (summoner?.isToken && tk.id === summoner.token?.id) || tk.actorId === baseId);
  const grid = scene.grid?.size ?? 100;
  const tokens = [];
  for (let i = 0; i < count; i++) {
    const x = sTok ? sTok.x + (Number(sTok.width) || 1) * grid + i * grid : grid * (i + 1);
    const y = sTok ? sTok.y : grid;
    const td = await actor.getTokenDocument({ x, y, disposition: sTok?.disposition ?? 1, flags: { jjk5e: { summonedBy: actorUuid } } });
    tokens.push(td.toObject());
  }
  await scene.createEmbeddedDocuments("Token", tokens);
}

async function gmDismiss({ actorUuid, sceneId }) {
  const scene = game.scenes.get(sceneId) ?? canvas.scene;
  if (!scene) return;
  const ids = scene.tokens.filter((tk) => tk.flags?.jjk5e?.summonedBy === actorUuid).map((tk) => tk.id);
  if (ids.length) await scene.deleteEmbeddedDocuments("Token", ids);
}

function viaGM(action, payload) {
  if (game.user.isGM) return action === "summon" ? gmSummon(payload) : gmDismiss(payload);
  const gm = game.users.activeGM ?? game.users.find((u) => u.isGM && u.active);
  if (!gm) return ui.notifications.warn(t("Notify.NoGM"));
  game.socket.emit(`module.${MODULE_ID}`, { action, payload, gm: gm.id });
}

async function summon(actor, name, count = 1) {
  actor = requireActor(actor);
  if (!actor || !name) return;
  return viaGM("summon", { actorUuid: actor.uuid, name, count: clamp(Number(count) || 1, 1, 20), userId: game.user.id, sceneId: canvas.scene?.id });
}

async function dismissSummons(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  return viaGM("dismiss", { actorUuid: actor.uuid, sceneId: canvas.scene?.id });
}

/* -------------------------------------------- */
/*  Effect expiry (when Times Up is not active)  */
/* -------------------------------------------- */

async function expireEffects() {
  if (!game.user.isGM || !setting("autoExpire") || game.modules.get("times-up")?.active) return;
  const actors = new Set();
  game.combat?.combatants?.forEach((c) => c.actor && actors.add(c.actor));
  canvas?.scene?.tokens?.forEach((tk) => tk.actor && actors.add(tk.actor));
  game.actors?.forEach((a) => a.type === "character" && actors.add(a));
  for (const actor of actors) {
    const ids = actor.effects.filter((e) => {
      const kind = e.flags?.jjk5e?.kind;
      if (!["zone", "burnout", "domain"].includes(kind)) return false;
      const rem = e.duration?.remaining;
      return rem !== null && rem !== undefined && rem <= 0;
    }).map((e) => e.id);
    for (const id of ids) await actor.effects.get(id)?.delete();
    for (const item of actor.items) for (const e of item.effects ?? []) {
      if (!e.flags?.jjk5e?.group || e.disabled) continue;
      const rem = e.duration?.remaining;
      if (rem !== null && rem !== undefined && rem <= 0) await e.update({ disabled: true });
    }
  }
}

/* -------------------------------------------- */
/*  JJK Panel                                    */
/* -------------------------------------------- */

const PANELS = new Map();

function panelHTML(actor) {
  const pool = findPool(actor);
  const value = pool ? poolValue(pool) : 0;
  const max = pool ? poolMax(pool) : 0;
  const pct = max ? Math.round((value / max) * 100) : 0;
  const tech = actor.getFlag(MODULE_ID, "technique");
  const ab = actor.getFlag(MODULE_ID, "ceAbility");
  const ro = Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0;
  const soul = Number(actor.getFlag(MODULE_ID, "soulAwareness")) || 0;
  const limbs = actor.getFlag(MODULE_ID, "limbs") ?? {};
  const zone = zoneEffect(actor);
  const zoneStacks = Number(zone?.flags?.jjk5e?.zone) || 0;
  const hr = isHeavenlyOnly(actor);
  const statusRow = (on, label, action) => `<span class="jjk-chip ${on ? "on" : ""}">${label}${on && action
    ? ` <a data-action="${action}" title="${t("Common.End")}"><i class="fas fa-times"></i></a>` : ""}</span>`;
  const limbRows = LIMBS.map((l) => {
    const st = limbs[l.key] ?? "ok";
    const btn = (s) => `<button type="button" class="${st === s ? "active" : ""}" data-action="limb" data-limb="${l.key}" data-status="${s}">${t(`Limb.${s}`)}</button>`;
    return `<tr class="limb-${st}"><td>${t(`Limb.${l.key}`)}</td><td class="num">${limbThreshold(actor, l)}</td>`
      + `<td class="num">${limbThreshold(actor, l) * 2}</td><td class="btns">${btn("ok")}${btn("broken")}${btn("lost")}</td></tr>`;
  }).join("");
  const soulList = SOUL_ABILITIES.slice(0, soul).map((n) => `<li>${n}</li>`).join("");
  const suggestions = [...new Set([...Object.keys(SUMMON_ALIASES).map((k) => k.replace(/\b\w/g, (c) => c.toUpperCase())),
    ...game.actors.filter((a) => a.folder?.name === SUMMON_FOLDER || a.folder?.name === "JJK Shikigami").map((a) => a.name)])]
    .map((n) => `<option value="${esc(n)}"></option>`).join("");

  return `
  <section class="jjk-panel">
    <header class="jjk-head">
      <img src="${ICONS}/ce.svg" alt="">
      <div>
        <div class="jjk-name">${esc(actor.name)}</div>
        <div class="jjk-sub">${hr ? t("Panel.HR") : `${t("Panel.Technique")}: <strong>${esc(tech ?? t("Panel.None"))}</strong>`}
          ${hr ? "" : ` · ${t("Panel.CEAbility")}: <strong>${ab ? ab.toUpperCase() : "?"}</strong>`}</div>
      </div>
      ${hr ? "" : `<div class="jjk-head-btns">
        <button type="button" data-action="chooseTechnique" title="${t("Panel.ChooseTechnique")}"><i class="fas fa-hand-sparkles"></i></button>
        <button type="button" data-action="ceAbility" title="${t("Panel.SetAbility")}"><i class="fas fa-brain"></i></button></div>`}
    </header>

    ${pool ? `<fieldset><legend>${t("CE.Name")}</legend>
      <div class="jjk-bar"><div class="fill" style="width:${pct}%"></div><span>${value} / ${max}</span></div>
      <div class="jjk-row">
        <button type="button" data-action="ceMinus">−1</button><button type="button" data-action="cePlus">+1</button>
        <button type="button" data-action="ceSpend">${t("Panel.Spend")}</button><button type="button" data-action="ceRegain">${t("Panel.Regain")}</button>
        <button type="button" data-action="negEmotion" title="${t("CE.NegativeEmotion")}"><i class="fas fa-face-angry"></i></button>
        <button type="button" data-action="shortRest" title="${t("CE.ShortRestTitle")}"><i class="fas fa-bed"></i></button>
      </div></fieldset>` : (hr ? "" : `<p class="jjk-note">${t("Panel.NoPool")}</p>`)}

    <fieldset><legend>${t("Panel.Status")}</legend>
      <div class="jjk-row">
        ${statusRow(domainOpen(actor), t("Domain.Open"), "closeDomain")}
        ${statusRow(inBurnout(actor), t("Burnout.Name"), "clearBurnout")}
        ${statusRow(!!zone, zone ? `${t("Zone.Name")} ×${zoneStacks}` : t("Zone.Name"), "clearZone")}
        ${statusRow(!!actor.getFlag(MODULE_ID, "pendingBlackFlash"), "Black Flash ×3", "clearBF")}
        ${activeGroups(actor).map((g) => `<span class="jjk-chip on">${t(`Group.${g}`)} <a data-action="endGroup" data-group="${g}" title="${t("Common.End")}"><i class="fas fa-times"></i></a></span>`).join("")}
      </div></fieldset>

    ${hr ? "" : `<fieldset><legend>${t("Output.Title")}</legend>
      <div class="jjk-row">
        <button type="button" data-action="maxOutput"><i class="fas fa-bolt"></i> ${t("Output.Max")}</button>
        <span class="jjk-lbl">${t("Output.Reduced")}</span>
        <button type="button" data-action="roDown">−</button><strong class="jjk-num">${ro}</strong><button type="button" data-action="roUp">+</button>
      </div>
      ${ro ? `<p class="jjk-note">${RO_ROWS[ro]}</p>` : ""}</fieldset>`}

    <fieldset><legend>${t("Soul.Name")}</legend>
      <div class="jjk-row"><button type="button" data-action="soulDown">−</button><strong class="jjk-num">${soul}</strong>
      <button type="button" data-action="soulUp">+</button></div>
      ${soul ? `<ul class="jjk-list">${soulList}</ul>` : ""}</fieldset>

    <fieldset><legend>${t("Limb.Title")}</legend>
      <table class="jjk-limbs"><thead><tr><th></th><th>${t("Limb.Broken")}</th><th>${t("Limb.Lost")}</th><th></th></tr></thead>
      <tbody>${limbRows}</tbody></table>
      <div class="jjk-row"><button type="button" data-action="limbRoll"><i class="fas fa-dice-d6"></i> ${t("Limb.Roll")}</button></div>
    </fieldset>

    <fieldset><legend>${t("Summon.Title")}</legend>
      <div class="jjk-row">
        <input type="text" name="summonName" list="jjk-summon-${actor.id}" placeholder="${t("Summon.Placeholder")}">
        <datalist id="jjk-summon-${actor.id}">${suggestions}</datalist>
        <input type="number" name="summonCount" value="1" min="1" max="20" class="jjk-count">
        <button type="button" data-action="summon"><i class="fas fa-paw"></i></button>
        <button type="button" data-action="dismiss" title="${t("Summon.Dismiss")}"><i class="fas fa-ghost"></i></button>
      </div>
      <p class="jjk-note">${t("Summon.Hint")}</p></fieldset>
  </section>`;
}

const PANEL_ACTIONS = {
  ceMinus: (actor) => spendCE(actor, 1, t("CE.Spent")),
  cePlus: (actor) => spendCE(actor, -1, t("CE.Regained")),
  ceSpend: (actor) => promptCE("spend", actor),
  ceRegain: (actor) => promptCE("regain", actor),
  negEmotion: (actor) => negativeEmotion(actor),
  shortRest: (actor) => shortRestCE(actor),
  chooseTechnique: (actor) => chooseTechnique(actor),
  ceAbility: (actor) => chooseCEAbility(actor),
  closeDomain: (actor) => closeDomain(actor),
  clearBurnout: async (actor) => {
    const ids = actor.effects.filter((e) => e.flags?.jjk5e?.kind === "burnout" || e.flags?.jjk5e?.burnout).map((e) => e.id);
    if (ids.length) await actor.deleteEmbeddedDocuments("ActiveEffect", ids);
  },
  clearZone: async (actor) => { const z = zoneEffect(actor); if (z) await z.delete(); },
  clearBF: (actor) => actor.unsetFlag(MODULE_ID, "pendingBlackFlash"),
  endGroup: (actor, target) => endGroup(actor, target.dataset.group),
  maxOutput: (actor) => maximumOutput(actor),
  roDown: (actor) => setReducedOutput(actor, (Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0) - 1),
  roUp: (actor) => setReducedOutput(actor, (Number(actor.getFlag(MODULE_ID, "reducedOutput")) || 0) + 1),
  soulDown: (actor) => setSoulAwareness(actor, (Number(actor.getFlag(MODULE_ID, "soulAwareness")) || 0) - 1),
  soulUp: (actor) => setSoulAwareness(actor, (Number(actor.getFlag(MODULE_ID, "soulAwareness")) || 0) + 1),
  limb: (actor, target) => setLimb(actor, target.dataset.limb, target.dataset.status),
  limbRoll: (actor) => rollLimb(actor),
  summon: (actor, target, root) => summon(actor, root.querySelector("[name=summonName]")?.value,
    root.querySelector("[name=summonCount]")?.valueAsNumber),
  dismiss: (actor) => dismissSummons(actor)
};

function makePanelClass() {
  const Base = foundry.applications?.api?.ApplicationV2;
  if (!Base) return null;
  const actions = {};
  for (const [name, fn] of Object.entries(PANEL_ACTIONS)) {
    actions[name] = async function (event, target) {
      try { await fn(this.actor, target, this.element); } catch (err) { console.error(err); ui.notifications.error(String(err.message ?? err)); }
      this.render();
    };
  }
  return class JJKPanel extends Base {
    static DEFAULT_OPTIONS = {
      classes: ["jjk5e-panel-app"],
      window: { icon: "fas fa-yin-yang", resizable: true },
      position: { width: 460, height: "auto" },
      actions
    };

    constructor(actor, options = {}) {
      super(foundry.utils.mergeObject({ id: `jjk5e-panel-${actor.uuid.replace(/\./g, "-")}` }, options));
      this.actor = actor;
    }

    get title() { return `JJK — ${this.actor.name}`; }

    async _renderHTML() { return panelHTML(this.actor); }

    _replaceHTML(result, content) { content.innerHTML = result; }

    _onClose(options) {
      PANELS.delete(this.actor.uuid);
      return super._onClose?.(options);
    }
  };
}

let JJKPanelClass = null;

function openPanel(actor) {
  actor = requireActor(actor);
  if (!actor) return;
  if (!actor.isOwner) return ui.notifications.warn(t("Notify.NotOwner"));
  JJKPanelClass ??= makePanelClass();
  if (!JJKPanelClass) return ui.notifications.error("ApplicationV2 not available.");
  let app = PANELS.get(actor.uuid);
  if (!app) {
    app = new JJKPanelClass(actor);
    PANELS.set(actor.uuid, app);
  }
  syncResource(actor);
  return app.render({ force: true });
}

function refreshPanels(actor) {
  if (!actor) return;
  const app = PANELS.get(actor.uuid);
  if (app?.rendered) app.render();
}

function addHeaderButton(app, root) {
  if (!setting("headerButton")) return;
  const actor = app.actor ?? app.document;
  if (!actor || actor.documentName !== "Actor" || actor.type !== "character" || !actor.isOwner) return;
  root = root instanceof HTMLElement ? root : root?.[0];
  const el = app.element instanceof HTMLElement ? app.element : app.element?.[0] ?? root;
  const header = el?.querySelector?.(".window-header") ?? root?.closest?.(".app, .application")?.querySelector(".window-header");
  if (!header || header.querySelector(".jjk5e-open")) return;
  const isV2 = header.tagName === "HEADER" && !!el?.classList?.contains("application");
  const btn = document.createElement(isV2 ? "button" : "a");
  btn.className = isV2 ? "header-control icon jjk5e-open" : "header-button control jjk5e-open";
  btn.type = isV2 ? "button" : undefined;
  btn.title = t("Panel.Open");
  btn.innerHTML = isV2 ? `<i class="fas fa-yin-yang"></i>` : `<i class="fas fa-yin-yang"></i>JJK`;
  btn.addEventListener("click", (ev) => { ev.preventDefault(); ev.stopPropagation(); openPanel(actor); });
  const anchor = header.querySelector('[data-action="close"], .close, .header-button.close');
  if (anchor) anchor.before(btn);
  else header.append(btn);
}

/* -------------------------------------------- */
/*  Init / Ready                                 */
/* -------------------------------------------- */

Hooks.once("init", () => {
  const reg = (key, type, def, extra = {}) => game.settings.register(MODULE_ID, key, {
    name: `JJK5E.Settings.${key}.Name`, hint: `JJK5E.Settings.${key}.Hint`,
    scope: "world", config: true, type, default: def, ...extra
  });
  game.settings.register(MODULE_ID, "importedVersion", { scope: "world", config: false, type: String, default: "" });
  reg("autoSpendCE", Boolean, true);
  reg("ceChat", Boolean, true);
  reg("ceResource", String, "tertiary", {
    choices: { none: "JJK5E.Settings.ceResource.None", primary: "JJK5E.Settings.ceResource.Primary",
      secondary: "JJK5E.Settings.ceResource.Secondary", tertiary: "JJK5E.Settings.ceResource.Tertiary" }
  });
  reg("autoTokenBar", Boolean, true);
  reg("blackFlash", Boolean, true);
  reg("blackFlashDamage", Boolean, true);
  reg("zoneAdvantage", Boolean, true);
  reg("domainTracking", Boolean, true);
  reg("domainSureHit", Boolean, true);
  reg("autoExpire", Boolean, true);
  reg("modifierReminders", Boolean, true);
  reg("checkPrereqs", Boolean, true);
  reg("headerButton", Boolean, true, { scope: "client" });
  game.settings.registerMenu(MODULE_ID, "importMenu", {
    name: "JJK5E.Settings.importMenu.Name", label: "JJK5E.Settings.importMenu.Label",
    hint: "JJK5E.Settings.importMenu.Hint", icon: "fas fa-file-import", type: JJKImportMenu, restricted: true
  });

  game.modules.get(MODULE_ID).api = {
    importAll, promptImport, spendCE,
    regainCE: (actor, amount, label) => spendCE(actor, -Math.abs(amount), label || t("CE.Regained")),
    findPool, chooseTechnique, syncTechnique, promptCE, shortRestCE, chooseCEAbility, negativeEmotion,
    applyScaling, openPanel, maximumOutput, setReducedOutput, setSoulAwareness, setLimb, rollLimb,
    summon, dismissSummons, syncResource, missingPrereqs, applyCEEffects, activateGroup, endGroup
  };
});

Hooks.once("ready", async () => {
  if (game.system.id !== "dnd5e") {
    ui.notifications.error(t("Notify.NeedDnd5e"));
    return;
  }
  registerActivityHooks();

  Hooks.on("dnd5e.advancementManagerComplete", async (manager) => {
    const actor = manager?.actor;
    if (!actor?.isOwner) return;
    if (actor.getFlag(MODULE_ID, "technique")) await syncTechnique(actor);
    await applyScaling(actor);
  });
  let pending = new Set();
  Hooks.on("createItem", (item, options, userId) => {
    if (userId !== game.user.id || !item.actor || !item.flags?.jjk5e) return;
    pending.add(item.actor);
    setTimeout(() => { const list = [...pending]; pending = new Set(); list.forEach((a) => applyScaling(a)); }, 250);
  });
  Hooks.on("deleteItem", (item, options, userId) => {
    if (userId === game.user.id && item.actor && (item.flags?.jjk5e?.ceMaxBonus || item.flags?.jjk5e?.cePool)) applyScaling(item.actor);
    refreshPanels(item.actor);
  });
  Hooks.on("updateItem", (item, changes, options, userId) => {
    if (userId === game.user.id && item.flags?.jjk5e?.cePool && !options?.jjk5eSync) syncResource(item.actor);
    refreshPanels(item.actor);
  });
  Hooks.on("updateActor", (actor, changes, options, userId) => {
    onActorUpdate(actor, changes, options, userId);
    refreshPanels(actor);
  });
  for (const h of ["createActiveEffect", "updateActiveEffect", "deleteActiveEffect"]) {
    Hooks.on(h, (effect) => refreshPanels(effect.parent?.documentName === "Actor" ? effect.parent : effect.parent?.actor));
  }
  Hooks.on("deleteActiveEffect", onDeleteEffect);
  Hooks.on("preCreateItem", onPreCreateItem);

  Hooks.on("dnd5e.rollAttackV2", (rolls, data) => onAttackRoll(rolls, data?.subject));
  Hooks.on("dnd5e.rollAttack", (a, b) => {
    if (Array.isArray(a)) return onAttackRoll(a, b?.subject);
    if (b && typeof b === "object" && "isCritical" in b) return onAttackRoll(b, a?.system?.activities?.contents?.[0] ?? a);
  });
  Hooks.on("dnd5e.preRollAttackV2", (config) => onPreRollAttack(config));
  Hooks.on("dnd5e.preRollDamageV2", (config) => onPreRollDamage(config));

  Hooks.on("updateCombat", () => expireEffects());
  Hooks.on("dnd5e.restCompleted", async (actor, result) => {
    if (!actor?.isOwner || result?.longRest) return;
    const n = actor.items.reduce((tot, i) => tot + (Number(i.flags?.jjk5e?.srRegainCE) || 0), 0);
    if (n > 0 && findPool(actor)) await spendCE(actor, -n, t("CE.ShortRestRestore", { n }));
  });
  Hooks.on("updateWorldTime", () => expireEffects());

  Hooks.on("renderActorSheet", (app, html) => addHeaderButton(app, html));
  Hooks.on("renderActorSheetV2", (app, element) => addHeaderButton(app, element));

  game.socket.on(`module.${MODULE_ID}`, (msg) => {
    if (!game.user.isGM || (msg.gm && msg.gm !== game.user.id)) return;
    if (msg.action === "summon") gmSummon(msg.payload);
    if (msg.action === "dismiss") gmDismiss(msg.payload);
  });

  if (game.user.character) syncResource(game.user.character);
  if (game.user.isGM && setting("importedVersion") !== DATA_VERSION) await promptImport(false);
});
